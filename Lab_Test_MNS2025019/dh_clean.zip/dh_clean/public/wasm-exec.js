// wasm-exec.js -- Pure WebAssembly loader for browser

let wasmInstance;
let modexp;

async function loadWasm() {
    const response = await fetch("/wasm/myProg.wasm");
    const bytes = await response.arrayBuffer();

    const result = await WebAssembly.instantiate(bytes, {
        env: {
            memory: new WebAssembly.Memory({ initial: 256 }),
            table: new WebAssembly.Table({ initial: 0, element: "anyfunc" })
        }
    });

    wasmInstance = result.instance;
    modexp = wasmInstance.exports.modexp;

    console.log("CLIENT: WASM loaded successfully.");
}

window.wasmReady = loadWasm(); // load automatically

window.wasmExec = {
    modexp: (a, b, p) => {
        return modexp(BigInt(a), BigInt(b), BigInt(p));
    }
};

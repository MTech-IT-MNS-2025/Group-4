document.getElementById("btn").addEventListener("click", async () => {
    await window.wasmReady; // wait for WASM to be ready

    const p = Number(document.getElementById("p").value);
    const g = Number(document.getElementById("g").value);

    // random a
    const a = Math.floor(Math.random() * (p - 2)) + 2;

    // Compute x = g^a mod p using WASM
    const x = wasmExec.modexp(g, a, p).toString();

    // Send to server
    const res = await fetch("/compute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ g, p, x })
    });

    const data = await res.json();

    document.getElementById("output").textContent =
        `a = ${a}\n` +
        `x = ${x}\n` +
        `b = ${data.b}\n` +
        `y = ${data.y}\n` +
        `K = ${data.K}\n`;
});

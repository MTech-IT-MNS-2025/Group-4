// app.js — works with your myProg.js which exposes Module as an async factory function

let wasmInstance = null;
let powmod = null;

// Immediately call the factory function exported as Module (it's an async factory)
(async () => {
  try {
    if (typeof Module !== "function") {
      console.error("Unexpected Module type:", typeof Module, Module);
      return;
    }
    // Module() returns a Promise that resolves to the runtime instance
    wasmInstance = await Module();
    console.log("WASM runtime instance ready (browser).");

    // Create JS wrapper to call exported C function 'modexp'
    powmod = wasmInstance.cwrap("modexp", "number", ["number","number","number"]);

    // enable the button (in case you want to disable it while loading)
    const btn = document.getElementById("genBtn");
    if (btn) btn.disabled = false;

  } catch (err) {
    console.error("Failed to initialize WASM Module():", err);
    alert("WASM load failed — see console");
  }
})();

async function computeDH() {
  if (!powmod) {
    alert("WASM not ready yet. Wait a moment and retry.");
    return;
  }

  const p = parseInt(document.getElementById("p").value, 10);
  const g = parseInt(document.getElementById("g").value, 10);
  if (!p || !g) { alert("Enter numeric p and g"); return; }

  const a = Math.floor(Math.random() * (p - 2)) + 2;
  const x = powmod(g, a, p);

  document.getElementById("client").innerHTML = `a = ${a}<br>x = ${x}`;

  try {
    const res = await fetch("/compute", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ g, p, x })
    });
    const data = await res.json();
    document.getElementById("server").innerHTML =
      `b = ${data.b}<br>y = ${data.y}<br>K = ${data.K}`;
  } catch (err) {
    console.error("Server request failed:", err);
    alert("Server request failed — see console");
  }
}

document.getElementById("genBtn").addEventListener("click", computeDH);


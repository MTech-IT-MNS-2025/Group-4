const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(express.json());

// Correct MIME for WASM
app.use((req, res, next) => {
    if (req.url.endsWith(".wasm")) {
        res.setHeader("Content-Type", "application/wasm");
    }
    next();
});

// Serve frontend
app.use("/", express.static(path.join(__dirname, "../public")));
app.use("/wasm", express.static(path.join(__dirname, "../wasm")));

// PURE WASM LOADING
let wasmInstance;
let modexp; // exported function from myProg.c

async function loadWasm() {
    const wasmPath = path.join(__dirname, "../wasm/myProg.wasm");
    const bytes = fs.readFileSync(wasmPath);

    const result = await WebAssembly.instantiate(bytes, {
        env: {
            memory: new WebAssembly.Memory({ initial: 256 }),
            table: new WebAssembly.Table({ initial: 0, element: "anyfunc" })
        }
    });

    wasmInstance = result.instance;
    modexp = wasmInstance.exports.modexp;

    console.log("SERVER: WASM loaded successfully.");
}

loadWasm();

// API Route
app.post("/compute", async (req, res) => {
    if (!modexp) return res.status(500).json({ error: "WASM not ready yet" });

    const { g, p, x } = req.body;

    // random b
    const b = Math.floor(Math.random() * (p - 2)) + 2;

    // compute using WASM (expects BigInt)
    const y = modexp(BigInt(g), BigInt(b), BigInt(p));
    const K = modexp(BigInt(x), BigInt(b), BigInt(p));

    res.json({
        b,
        y: y.toString(),
        K: K.toString()
    });
});

app.listen(3000, () => {
    console.log("SERVER RUNNING at http://localhost:3000");
});


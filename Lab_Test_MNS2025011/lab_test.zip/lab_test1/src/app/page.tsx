"use client";

import { useState } from "react";

export default function Home() {
  const [p, setP] = useState(2);
  const [g, setG] = useState(11);

  const [K, setK] = useState<number | null>(null);
  const [y, setY] = useState<number | null>(null);
  const [a, setA] = useState<number | null>(null);

  const connect = () => {
    // Dummy calculation (you will replace with WASM later)
    const A = 3;
    const Y = (g ** A) % p;
    const Kvalue = Y;

    setA(A);
    setY(Y);
    setK(Kvalue);
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        background: "#bcd4f6",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          width: "450px",
          padding: "40px",
          background: "#cce0ff",
          borderRadius: "12px",
          boxShadow: "0 0 10px rgba(0,0,0,0.15)",
          textAlign: "center",
        }}
      >
        {/* Input p */}
        <div style={{ marginBottom: "20px", textAlign: "left" }}>
          <label style={{ fontSize: "16px" }}>Enter the Value of p:</label>
          <input
            type="number"
            value={p}
            onChange={(e) => setP(Number(e.target.value))}
            style={{
              width: "70%",
              padding: "8px",
              marginLeft: "20px",
              borderRadius: "6px",
              border: "1px solid #777",
            }}
          />
        </div>

        {/* Input g */}
        <div style={{ marginBottom: "30px", textAlign: "left" }}>
          <label style={{ fontSize: "16px" }}>Enter the Value of g:</label>
          <input
            type="number"
            value={g}
            onChange={(e) => setG(Number(e.target.value))}
            style={{
              width: "70%",
              padding: "8px",
              marginLeft: "20px",
              borderRadius: "6px",
              border: "1px solid #777",
            }}
          />
        </div>

        {/* Connect button */}
        <button
          onClick={connect}
          style={{
            padding: "10px 20px",
            borderRadius: "6px",
            background: "white",
            border: "1px solid #555",
            cursor: "pointer",
            fontWeight: "bold",
            marginBottom: "30px",
          }}
        >
          CONNECT
        </button>

        {/* Output box */}
        {K !== null && y !== null && a !== null && (
          <div
            style={{
              width: "70%",
              height: "120px",
              margin: "0 auto",
              border: "1px solid #333",
              borderRadius: "6px",
              padding: "10px",
              textAlign: "left",
              background: "white",
            }}
          >
            <p>K = {K + 9}</p>
            <p>y = {y + 9}</p>
            <p>a = {a}</p>
          </div>
        )}
      </div>
    </div>
  );
}

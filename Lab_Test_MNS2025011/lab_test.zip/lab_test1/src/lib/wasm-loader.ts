export interface WasmModule {
  _modexp_wrapper(a: number, b: number, n: number): number;
}

declare global {
  interface Window {
    createModule?: (opts?: any) => Promise<WasmModule>;
  }
}

export async function loadWasm(): Promise<WasmModule> {
  if (typeof window === "undefined") {
    throw new Error("WASM must run in browser");
  }

  if (window.createModule) {
    return window.createModule();
  }

  await new Promise<void>((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "/wasm/module.js";
    script.onload = () => resolve();
    script.onerror = () => reject("Failed to load module.js");
    document.body.appendChild(script);
  });

  return window.createModule!();
}

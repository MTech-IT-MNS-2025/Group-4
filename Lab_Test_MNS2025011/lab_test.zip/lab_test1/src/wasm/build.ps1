$ErrorActionPreference = "Stop"

Write-Host "=== Building WASM ===" -ForegroundColor Cyan

# Load EMSDK
& "C:\emsdk\emsdk_env.ps1"

# Compile WASM
emcc modexp.c -O3 `
  -s WASM=1 `
  -s EXPORTED_FUNCTIONS='["_modexp_wrapper"]' `
  -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap"]' `
  -s MODULARIZE=1 `
  -s EXPORT_NAME="createModule" `
  -o ../../public/wasm/module.js

Write-Host "=== WASM Build Complete ===" -ForegroundColor Green

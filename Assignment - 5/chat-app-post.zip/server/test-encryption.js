// Run this in your server directory to test encryption/decryption
// node test-encryption.js

const crypto = require('crypto');
const path = require('path');

// Load the crypto utils
const cryptoUtils = require('./crypto-utils');

console.log('🧪 Testing PQC Encryption/Decryption Flow\n');

// Step 1: Generate keypair
console.log('1️⃣ Generating KEM keypair...');
const keypair = cryptoUtils.generateKEMKeypair();
console.log('✅ Public key length:', keypair.publicKey.length);
console.log('✅ Secret key length:', keypair.secretKey.length);
console.log('✅ Algorithm:', keypair.algorithm);
console.log('');

// Step 2: Encrypt a test message
console.log('2️⃣ Encrypting test message...');
const testMessage = 'Hello, this is a test message! 🔐';
console.log('📝 Original message:', testMessage);

const encrypted = cryptoUtils.encryptMessageForReceiver(testMessage, keypair.publicKey);
console.log('✅ Encrypted message length:', encrypted.encryptedMessage.length);
console.log('✅ KEM ciphertext length:', encrypted.kemCiphertext.length);
console.log('✅ IV length:', encrypted.iv.length);
console.log('✅ Auth tag length:', encrypted.authTag.length);
console.log('');

// Step 3: Decapsulate to get session key
console.log('3️⃣ Decapsulating KEM to recover session key...');
const sessionKey = cryptoUtils.kemDecapsulate(encrypted.kemCiphertext, keypair.secretKey);
console.log('✅ Session key recovered, length:', sessionKey.length);
console.log('');

// Step 4: Decrypt the message manually
console.log('4️⃣ Decrypting message with session key...');
try {
    // Decode base64
    const encryptedBytes = Buffer.from(encrypted.encryptedMessage, 'base64');
    const ivBytes = Buffer.from(encrypted.iv, 'base64');
    const authTagBytes = Buffer.from(encrypted.authTag, 'base64');
    
    console.log('📊 Decoded lengths:');
    console.log('   - Encrypted:', encryptedBytes.length);
    console.log('   - IV:', ivBytes.length);
    console.log('   - Auth tag:', authTagBytes.length);
    console.log('   - Session key:', sessionKey.length);
    
    // Create decipher
    const decipher = crypto.createDecipheriv('aes-256-gcm', sessionKey, ivBytes);
    decipher.setAuthTag(authTagBytes);
    
    // Decrypt
    let decrypted = decipher.update(encryptedBytes);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    
    const decryptedText = decrypted.toString('utf8');
    console.log('');
    console.log('✅ Decryption successful!');
    console.log('📝 Decrypted message:', decryptedText);
    console.log('');
    
    if (decryptedText === testMessage) {
        console.log('🎉 SUCCESS! Encryption/Decryption works correctly!');
    } else {
        console.log('❌ MISMATCH! Original and decrypted messages differ!');
        console.log('Expected:', testMessage);
        console.log('Got:', decryptedText);
    }
} catch (err) {
    console.error('❌ Decryption failed:', err.message);
    console.error(err);
}

console.log('\n' + '='.repeat(60));
console.log('🔬 Now testing Web Crypto API format (browser-compatible)');
console.log('='.repeat(60) + '\n');

// Test with combined format (how Web Crypto expects it)
console.log('5️⃣ Testing Web Crypto API format...');
const encryptedBytes = Buffer.from(encrypted.encryptedMessage, 'base64');
const authTagBytes = Buffer.from(encrypted.authTag, 'base64');

// Web Crypto expects ciphertext + authTag combined
const combined = Buffer.concat([encryptedBytes, authTagBytes]);
console.log('📦 Combined length:', combined.length);
console.log('   = Encrypted (', encryptedBytes.length, ') + Auth Tag (', authTagBytes.length, ')');
console.log('');

console.log('✅ Test complete! If decryption succeeded, the issue is client-side.');
console.log('If it failed, the issue is server-side encryption.');

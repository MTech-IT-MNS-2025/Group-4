// ------------------ IMPORTS ------------------
const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');
const { Server } = require('socket.io');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

// Import PQC crypto utilities
let cryptoUtils;
try {
  cryptoUtils = require('./crypto-utils');
  console.log('✅ PQC Crypto utilities loaded');
} catch (err) {
  console.error('❌ Failed to load crypto utilities:', err);
  console.error('Please ensure you have built the native addon first!');
  process.exit(1);
}

// ------------------ APP SETUP ------------------
const dev = process.env.NODE_ENV !== 'production';
const hostname = 'localhost';
const port = 3000;

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

const expressApp = express();
expressApp.use(cors());
expressApp.use(express.json());

// ✅ Serve static files from the *main public folder*
expressApp.use('/uploads', express.static(path.join(__dirname, '../public/uploads')));
expressApp.use('/profiles', express.static(path.join(__dirname, '../public/profiles')));

// ------------------ DATABASE SETUP ------------------
const dbPath = path.join(__dirname, 'chat.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('❌ Database connection error:', err);
  } else {
    console.log('✅ Connected to SQLite database');
    initializeDatabase();
  }
});

// Initialize database tables
function initializeDatabase() {
  // Users table with PQC keys
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    profile_picture TEXT,
    pqc_public_key TEXT NOT NULL,
    pqc_algorithm TEXT DEFAULT 'Kyber768',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`, (err) => {
    if (err) console.error('Error creating users table:', err);
    else console.log('✅ Users table ready');
  });

  // Messages table with encryption metadata
  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender TEXT NOT NULL,
    receiver TEXT NOT NULL,
    encrypted_message TEXT NOT NULL,
    kem_ciphertext TEXT NOT NULL,
    iv TEXT NOT NULL,
    auth_tag TEXT NOT NULL,
    image_url TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_group BOOLEAN DEFAULT 0,
    group_name TEXT
  )`, (err) => {
    if (err) console.error('Error creating messages table:', err);
    else console.log('✅ Messages table ready');
  });

  // Groups table
  db.run(`CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_name TEXT UNIQUE NOT NULL,
    creator TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`, (err) => {
    if (err) console.error('Error creating groups table:', err);
    else console.log('✅ Groups table ready');
  });

  // Group members table
  db.run(`CREATE TABLE IF NOT EXISTS group_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_name TEXT NOT NULL,
    username TEXT NOT NULL,
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(group_name, username)
  )`, (err) => {
    if (err) console.error('Error creating group_members table:', err);
    else console.log('✅ Group members table ready');
  });
}

// ------------------ API ROUTES ------------------

// Registration endpoint with PQC keypair generation
expressApp.post('/api/register', async (req, res) => {
  const { username, password, profilePicture } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password required' });
  }
  
  try {
    // Generate PQC keypair
    console.log(`🔐 Generating PQC keypair for ${username}...`);
    const keypair = cryptoUtils.generateKEMKeypair();
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Store user with public key (secret key is NOT stored on server)
    db.run(
      `INSERT INTO users (username, password, profile_picture, pqc_public_key, pqc_algorithm) 
       VALUES (?, ?, ?, ?, ?)`,
      [username, hashedPassword, profilePicture || null, keypair.publicKey, keypair.algorithm],
      function(err) {
        if (err) {
          console.error('Registration error:', err);
          return res.status(500).json({ message: 'Username already exists or database error' });
        }
        
        console.log(`✅ User ${username} registered successfully with PQC keys`);
        
        // Return secret key to user - they must store it securely client-side
        res.json({
          message: 'Registration successful',
          username: username,
          secretKey: keypair.secretKey, // ⚠️ User must save this!
          publicKey: keypair.publicKey,
          algorithm: keypair.algorithm,
          profilePicture: profilePicture
        });
      }
    );
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ message: 'Registration failed' });
  }
});

// Login endpoint
expressApp.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password required' });
  }
  
  db.get(
    'SELECT * FROM users WHERE username = ?',
    [username],
    async (err, user) => {
      if (err || !user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Verify password
      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      console.log(`✅ User ${username} logged in`);
      
      res.json({
        message: 'Login successful',
        username: user.username,
        profilePicture: user.profile_picture,
        publicKey: user.pqc_public_key
      });
    }
  );
});

// Get user's public key
expressApp.get('/api/public-key/:username', (req, res) => {
  const { username } = req.params;
  
  db.get(
    'SELECT pqc_public_key, pqc_algorithm FROM users WHERE username = ?',
    [username],
    (err, user) => {
      if (err || !user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json({
        username: username,
        publicKey: user.pqc_public_key,
        algorithm: user.pqc_algorithm
      });
    }
  );
});

// Decryption endpoint - decapsulates KEM and returns session key
expressApp.post('/api/decrypt-kem', (req, res) => {
  const { kemCiphertext, secretKey } = req.body;
  
  if (!kemCiphertext || !secretKey) {
    console.error('❌ Missing parameters for decryption');
    return res.status(400).json({ message: 'Missing required parameters' });
  }
  
  console.log('🔓 Decapsulation request received');
  console.log('📊 Data lengths:', {
    kemCiphertext: kemCiphertext.length,
    secretKey: secretKey.length
  });
  
  try {
    const sessionKey = cryptoUtils.kemDecapsulate(kemCiphertext, secretKey);
    console.log('✅ KEM decapsulation successful, session key length:', sessionKey.length);
    res.json({ sessionKey: sessionKey.toString('base64') });
  } catch (err) {
    console.error('❌ Decapsulation error:', err.message);
    console.error('This usually means: wrong secret key or corrupted ciphertext');
    res.status(500).json({ 
      message: 'Decryption failed',
      error: err.message 
    });
  }
});

// Get message history (encrypted)
expressApp.get('/api/messages/:username', (req, res) => {
  const { username } = req.params;
  
  db.all(
    `SELECT * FROM messages 
     WHERE (sender = ? OR receiver = ?) AND is_group = 0
     ORDER BY timestamp ASC`,
    [username, username],
    (err, messages) => {
      if (err) {
        console.error('Error fetching messages:', err);
        return res.status(500).json({ message: 'Failed to fetch messages' });
      }
      res.json({ messages });
    }
  );
});

// ------------------ FILE UPLOAD SETUP ------------------
const uploadsDir = path.join(__dirname, '../public/uploads');
const profilesDir = path.join(__dirname, '../public/profiles');

// Ensure folders exist
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
if (!fs.existsSync(profilesDir)) fs.mkdirSync(profilesDir, { recursive: true });

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const type = req.body.type === 'profile' ? profilesDir : uploadsDir;
    cb(null, type);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

// ------------------ FILE UPLOAD ROUTE ------------------
expressApp.post('/api/upload', upload.single('file'), (req, res) => {
  try {
    const type = req.body.type === 'profile' ? 'profiles' : 'uploads';
    const filePath = `/${type}/${req.file.filename}`; // ✅ public path
    res.json({ url: filePath });
  } catch (err) {
    console.error('❌ Upload failed:', err);
    res.status(500).json({ message: 'Upload failed' });
  }
});

// ------------------ START NEXT + SOCKET.IO ------------------
app.prepare().then(() => {
  const server = createServer((req, res) => {
    if (req.url.startsWith('/api/')) {
      expressApp(req, res);
    } else {
      handle(req, res, parse(req.url, true));
    }
  });

  const io = new Server(server, {
    cors: { origin: '*' },
  });

  // ------------------ SOCKET.IO HANDLERS ------------------
  const activeUsers = new Map(); // username -> { socketId, status, publicKey }
  const userSockets = new Map(); // socketId -> username

  io.on('connection', (socket) => {
    console.log('✅ User connected:', socket.id);

    // Register user
    socket.on('register_user', (data) => {
      const { username, profilePicture } = data;
      
      // Get user's public key from database
      db.get('SELECT pqc_public_key FROM users WHERE username = ?', [username], (err, user) => {
        if (!err && user) {
          activeUsers.set(username, {
            socketId: socket.id,
            status: 'online',
            publicKey: user.pqc_public_key,
            profilePicture
          });
          userSockets.set(socket.id, username);
          
          console.log(`🟢 ${username} registered (Socket: ${socket.id})`);
          
          // Broadcast status to all clients
          io.emit('user_status', { username, status: 'online' });
        }
      });
    });

    // Get all user statuses
    socket.on('get_all_statuses', () => {
      const statuses = {};
      activeUsers.forEach((data, username) => {
        statuses[username] = data.status;
      });
      socket.emit('all_users_status', statuses);
    });

    // Handle private encrypted messages
    socket.on('send_message', async (data) => {
      const { sender, receiver, text, imageUrl } = data;
      
      console.log(`📨 Processing encrypted message from ${sender} to ${receiver}`);
      
      try {
        // Get receiver's public key from database
        db.get('SELECT pqc_public_key FROM users WHERE username = ?', [receiver], (err, user) => {
          if (err || !user) {
            console.error(`❌ Receiver ${receiver} not found`);
            socket.emit('message_error', { message: 'Receiver not found' });
            return;
          }
          
          try {
            // Encrypt message for receiver using their public key
            const encrypted = cryptoUtils.encryptMessageForReceiver(
              text,
              user.pqc_public_key
            );
            
            // Store encrypted message in database
            db.run(
              `INSERT INTO messages (sender, receiver, encrypted_message, kem_ciphertext, iv, auth_tag, image_url, is_group) 
               VALUES (?, ?, ?, ?, ?, ?, ?, 0)`,
              [sender, receiver, encrypted.encryptedMessage, encrypted.kemCiphertext, encrypted.iv, encrypted.authTag, imageUrl || null],
              function(err) {
                if (err) {
                  console.error('Error storing message:', err);
                  return;
                }
                
                // Prepare message payload
                const messagePayload = {
                  sender,
                  receiver,
                  encryptedMessage: encrypted.encryptedMessage,
                  kemCiphertext: encrypted.kemCiphertext,
                  iv: encrypted.iv,
                  authTag: encrypted.authTag,
                  imageUrl: imageUrl || null,
                  timestamp: new Date(),
                  isGroup: false
                };
                
                // Send to receiver if online
                const receiverData = activeUsers.get(receiver);
                if (receiverData) {
                  io.to(receiverData.socketId).emit('receive_encrypted_message', messagePayload);
                  console.log(`✅ Encrypted message sent to ${receiver}`);
                }
                
                // Send back to sender (for their own chat history)
                socket.emit('receive_encrypted_message', messagePayload);
                
                // Send notification to receiver
                if (receiverData) {
                  io.to(receiverData.socketId).emit('notification', {
                    sender,
                    message: 'New encrypted message'
                  });
                }
                
                console.log(`✅ Encrypted message stored (ID: ${this.lastID})`);
              }
            );
          } catch (encryptErr) {
            console.error('Encryption error:', encryptErr);
            socket.emit('message_error', { message: 'Encryption failed' });
          }
        });
      } catch (err) {
        console.error('Error handling encrypted message:', err);
        socket.emit('message_error', { message: 'Message processing failed' });
      }
    });

    // Create group
    socket.on('create_group', (data) => {
      const { groupName, creator } = data;
      
      db.run(
        'INSERT INTO groups (group_name, creator) VALUES (?, ?)',
        [groupName, creator],
        function(err) {
          if (err) {
            console.error('Error creating group:', err);
            socket.emit('group_error', { message: 'Group name already exists' });
            return;
          }
          
          // Add creator as first member
          db.run(
            'INSERT INTO group_members (group_name, username) VALUES (?, ?)',
            [groupName, creator],
            (err) => {
              if (err) {
                console.error('Error adding creator to group:', err);
              }
            }
          );
          
          io.emit('group_created', { groupName });
          console.log(`✅ Group created: ${groupName} by ${creator}`);
        }
      );
    });

    // Join group
    socket.on('join_group', (data) => {
      const { groupName, username } = data;
      
      socket.join(groupName);
      
      db.run(
        'INSERT OR IGNORE INTO group_members (group_name, username) VALUES (?, ?)',
        [groupName, username],
        (err) => {
          if (err) {
            console.error('Error joining group:', err);
            return;
          }
          
          console.log(`✅ ${username} joined group: ${groupName}`);
          
          // Get group members
          db.all(
            'SELECT username FROM group_members WHERE group_name = ?',
            [groupName],
            (err, members) => {
              if (!err) {
                io.to(groupName).emit('group_members', {
                  groupName,
                  members: members.map(m => m.username)
                });
              }
            }
          );
          
          // Notify group
          io.to(groupName).emit('user_joined_group', {
            groupName,
            username
          });
        }
      );
    });

    // Send group message (for now, unencrypted - can be enhanced)
    socket.on('send_group_message', (data) => {
      const { sender, groupName, text, imageUrl } = data;
      
      const messagePayload = {
        sender,
        groupName,
        text,
        imageUrl: imageUrl || null,
        timestamp: new Date(),
        isGroup: true
      };
      
      // Broadcast to all members in the group
      io.to(groupName).emit('receive_group_message', messagePayload);
      
      console.log(`✅ Group message sent to ${groupName} by ${sender}`);
    });

    // Get all groups
    socket.on('get_groups', () => {
      db.all('SELECT group_name FROM groups', [], (err, groups) => {
        if (!err) {
          socket.emit('all_groups', groups.map(g => g.group_name));
        }
      });
    });

    // Typing indicators for private chat
    socket.on('typing', (data) => {
      const { sender, receiver } = data;
      const receiverData = activeUsers.get(receiver);
      if (receiverData) {
        io.to(receiverData.socketId).emit('user_typing', { sender });
      }
    });

    socket.on('stop_typing', (data) => {
      const { sender, receiver } = data;
      const receiverData = activeUsers.get(receiver);
      if (receiverData) {
        io.to(receiverData.socketId).emit('user_stopped_typing');
      }
    });

    // Typing indicators for group chat
    socket.on('typing_group', (data) => {
      const { groupName, sender } = data;
      socket.to(groupName).emit('user_typing', { sender });
    });

    socket.on('stop_typing_group', (data) => {
      const { groupName } = data;
      socket.to(groupName).emit('user_stopped_typing');
    });

    // Disconnect handler
    socket.on('disconnect', () => {
      const username = userSockets.get(socket.id);
      if (username) {
        activeUsers.delete(username);
        userSockets.delete(socket.id);
        io.emit('user_status', { username, status: 'offline' });
        console.log(`🔴 ${username} disconnected`);
      }
    });
  });

  // ------------------ START SERVER ------------------
  server.listen(port, () => {
    console.log(`🚀 Server running on http://${hostname}:${port}`);
    console.log(`🔐 Post-Quantum Cryptography enabled with Kyber768`);
    console.log(`🖼️  Uploads served from: http://${hostname}:${port}/uploads`);
    console.log(`📁 Database: ${dbPath}`);
  });

  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\n⏹️  Shutting down server...');
    db.close((err) => {
      if (err) {
        console.error('Error closing database:', err);
      } else {
        console.log('✅ Database connection closed');
      }
      process.exit(0);
    });
  });
});

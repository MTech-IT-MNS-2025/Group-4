const crypto = require('crypto');
const path = require('path');

// Load native addon
let pqcrypto;
try {
    pqcrypto = require(path.join(__dirname, '../native-crypto/build/Release/pqcrypto.node'));
    console.log('✅ PQCrypto native addon loaded successfully');
} catch (err) {
    console.error('❌ Failed to load PQCrypto addon:', err);
    throw err;
}

/**
 * Generate PQC KEM keypair for a user
 * @returns {Object} { publicKey: Buffer, secretKey: Buffer, algorithm: string }
 */
function generateKEMKeypair() {
    try {
        const keypair = pqcrypto.generateKEMKeypair();
        return {
            publicKey: keypair.publicKey.toString('base64'),
            secretKey: keypair.secretKey.toString('base64'),
            algorithm: keypair.algorithm
        };
    } catch (err) {
        console.error('Error generating KEM keypair:', err);
        throw err;
    }
}

/**
 * Encrypt a message using AES-256-GCM with a session key
 * @param {string} message - Plain text message
 * @param {Buffer} sessionKey - 32-byte AES key
 * @returns {Object} { encryptedData: string, iv: string, authTag: string }
 */
function encryptMessage(message, sessionKey) {
    try {
        // Generate random IV (12 bytes for GCM)
        const iv = crypto.randomBytes(12);
        
        // Create cipher
        const cipher = crypto.createCipheriv('aes-256-gcm', sessionKey, iv);
        
        // Encrypt
        let encrypted = cipher.update(message, 'utf8', 'base64');
        encrypted += cipher.final('base64');
        
        // Get authentication tag
        const authTag = cipher.getAuthTag();
        
        return {
            encryptedData: encrypted,
            iv: iv.toString('base64'),
            authTag: authTag.toString('base64')
        };
    } catch (err) {
        console.error('Error encrypting message:', err);
        throw err;
    }
}

/**
 * Decrypt a message using AES-256-GCM
 * @param {Object} encryptedMsg - { encryptedData, iv, authTag }
 * @param {Buffer} sessionKey - 32-byte AES key
 * @returns {string} Decrypted message
 */
function decryptMessage(encryptedMsg, sessionKey) {
    try {
        const { encryptedData, iv, authTag } = encryptedMsg;
        
        // Create decipher
        const decipher = crypto.createDecipheriv(
            'aes-256-gcm',
            sessionKey,
            Buffer.from(iv, 'base64')
        );
        
        // Set auth tag
        decipher.setAuthTag(Buffer.from(authTag, 'base64'));
        
        // Decrypt
        let decrypted = decipher.update(encryptedData, 'base64', 'utf8');
        decrypted += decipher.final('utf8');
        
        return decrypted;
    } catch (err) {
        console.error('Error decrypting message:', err);
        throw err;
    }
}

/**
 * Encapsulate - Generate shared secret and ciphertext using receiver's public key
 * @param {string} publicKeyBase64 - Receiver's public key (base64)
 * @returns {Object} { sharedSecret: Buffer, ciphertext: string }
 */
function kemEncapsulate(publicKeyBase64) {
    try {
        const publicKey = Buffer.from(publicKeyBase64, 'base64');
        const result = pqcrypto.kemEncapsulate(publicKey);
        
        // Use first 32 bytes of shared secret as AES-256 key
        const sessionKey = result.sharedSecret.slice(0, 32);
        
        return {
            sessionKey: sessionKey,
            ciphertext: result.ciphertext.toString('base64')
        };
    } catch (err) {
        console.error('Error in KEM encapsulation:', err);
        throw err;
    }
}

/**
 * Decapsulate - Recover shared secret from ciphertext using secret key
 * @param {string} ciphertextBase64 - KEM ciphertext (base64)
 * @param {string} secretKeyBase64 - User's secret key (base64)
 * @returns {Buffer} Session key (32 bytes)
 */
function kemDecapsulate(ciphertextBase64, secretKeyBase64) {
    try {
        console.log('🔓 Starting KEM decapsulation...');
        console.log('📊 Input lengths:', {
            ciphertext: ciphertextBase64.length,
            secretKey: secretKeyBase64.length
        });
        
        const ciphertext = Buffer.from(ciphertextBase64, 'base64');
        const secretKey = Buffer.from(secretKeyBase64, 'base64');
        
        console.log('📊 Buffer lengths:', {
            ciphertext: ciphertext.length,
            secretKey: secretKey.length
        });
        
        const sharedSecret = pqcrypto.kemDecapsulate(ciphertext, secretKey);
        
        console.log('✅ KEM decapsulation successful, shared secret length:', sharedSecret.length);
        
        // Use first 32 bytes as AES-256 key
        const sessionKey = sharedSecret.slice(0, 32);
        console.log('✅ Session key extracted (32 bytes)');
        
        return sessionKey;
    } catch (err) {
        console.error('❌ Error in KEM decapsulation:', err);
        console.error('Stack trace:', err.stack);
        throw err;
    }
}

/**
 * Complete encryption flow: Encapsulate key + Encrypt message
 * @param {string} message - Plain text message
 * @param {string} receiverPublicKey - Receiver's public key (base64)
 * @returns {Object} { encryptedMessage, kemCiphertext, iv, authTag }
 */
function encryptMessageForReceiver(message, receiverPublicKey) {
    // Step 1: Encapsulate to get session key and KEM ciphertext
    const { sessionKey, ciphertext } = kemEncapsulate(receiverPublicKey);
    
    // Step 2: Encrypt message with session key
    const encrypted = encryptMessage(message, sessionKey);
    
    return {
        encryptedMessage: encrypted.encryptedData,
        kemCiphertext: ciphertext,
        iv: encrypted.iv,
        authTag: encrypted.authTag
    };
}

/**
 * Complete decryption flow: Decapsulate key + Decrypt message
 * @param {Object} encryptedData - { encryptedMessage, kemCiphertext, iv, authTag }
 * @param {string} userSecretKey - User's secret key (base64)
 * @returns {string} Decrypted message
 */
function decryptMessageFromSender(encryptedData, userSecretKey) {
    // Step 1: Decapsulate to recover session key
    const sessionKey = kemDecapsulate(encryptedData.kemCiphertext, userSecretKey);
    
    // Step 2: Decrypt message with session key
    const decrypted = decryptMessage({
        encryptedData: encryptedData.encryptedMessage,
        iv: encryptedData.iv,
        authTag: encryptedData.authTag
    }, sessionKey);
    
    return decrypted;
}

module.exports = {
    generateKEMKeypair,
    encryptMessage,
    decryptMessage,
    kemEncapsulate,
    kemDecapsulate,
    encryptMessageForReceiver,
    decryptMessageFromSender
};

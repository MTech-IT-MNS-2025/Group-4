export function storeSecretKey(username: string, secretKey: string): void {
    try {
        const obfuscated = btoa(secretKey);
        localStorage.setItem(`${username}_secret_key`, obfuscated);
        console.log('🔐 Secret key stored securely');
    } catch (err) {
        console.error('Error storing secret key:', err);
    }
}

export function getSecretKey(username: string): string | null {
    try {
        const obfuscated = localStorage.getItem(`${username}_secret_key`);
        if (!obfuscated) return null;
        return atob(obfuscated);
    } catch (err) {
        console.error('Error retrieving secret key:', err);
        return null;
    }
}

export function clearSecretKey(username: string): void {
    localStorage.removeItem(`${username}_secret_key`);
    console.log('🗑️ Secret key cleared');
}

export async function requestDecryption(
    kemCiphertext: string,
    secretKey: string
): Promise<ArrayBuffer> {
    const response = await fetch('/api/decrypt-kem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kemCiphertext, secretKey })
    });
    
    if (!response.ok) {
        throw new Error('Decryption request failed');
    }
    
    const data = await response.json();
    const sessionKeyBytes = Uint8Array.from(atob(data.sessionKey), c => c.charCodeAt(0));
    return sessionKeyBytes.buffer;
}

export function hasSecretKey(username: string): boolean {
    return localStorage.getItem(`${username}_secret_key`) !== null;
}

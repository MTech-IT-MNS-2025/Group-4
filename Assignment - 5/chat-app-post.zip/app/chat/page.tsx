'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { io, Socket } from 'socket.io-client';
import { storeSecretKey, getSecretKey, clearSecretKey } from '../crypto-browser';

interface Message {
  sender: string;
  receiver?: string;
  groupName?: string;
  text: string;
  imageUrl?: string;
  timestamp: Date;
  isGroup?: boolean;
  encryptedMessage?: string;
  kemCiphertext?: string;
  iv?: string;
  authTag?: string;
  isDecrypted?: boolean;
  decrypting?: boolean;
}

interface Notification {
  sender: string;
  message: string;
  timestamp: Date;
}

const emojis = ['😀', '😂', '😍', '🥰', '😎', '🤔', '😭', '😱', '🔥', '💯', '👍', '👎', '❤️', '💔', '🎉', '🎊', '✨', '⭐', '🌟', '💫'];

export default function ChatPage() {
  const [username, setUsername] = useState('');
  const [profilePicture, setProfilePicture] = useState('');
  const [recipient, setRecipient] = useState('');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [allMessages, setAllMessages] = useState<Message[]>([]); // Store ALL messages
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [userStatus, setUserStatus] = useState<{ [key: string]: string }>({});
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [typingUser, setTypingUser] = useState('');
  const [chatMode, setChatMode] = useState<'private' | 'group'>('private');
  const [groups, setGroups] = useState<string[]>([]);
  const [selectedGroup, setSelectedGroup] = useState('');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [groupMembers, setGroupMembers] = useState<string[]>([]);
  const [secretKey, setSecretKey] = useState('');
  const [hasKeyLoaded, setHasKeyLoaded] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const router = useRouter();

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(scrollToBottom, [messages]);

  // Load secret key on mount
  useEffect(() => {
    const storedUsername = localStorage.getItem('username');
    if (storedUsername) {
      const key = getSecretKey(storedUsername);
      if (key) {
        setSecretKey(key);
        setHasKeyLoaded(true);
        console.log('🔑 Secret key loaded for', storedUsername);
      } else {
        console.warn('⚠️ No secret key found - messages cannot be decrypted');
      }
    }
  }, []);

  // Filter messages when recipient or chat mode changes
  useEffect(() => {
    if (chatMode === 'private' && recipient) {
      // Show only messages between current user and selected recipient
      const filtered = allMessages.filter(msg => 
        !msg.isGroup && (
          (msg.sender === username && msg.receiver === recipient) ||
          (msg.sender === recipient && msg.receiver === username)
        )
      );
      setMessages(filtered);
      console.log(`📂 Filtered ${filtered.length} messages for chat with ${recipient}`);
    } else if (chatMode === 'group' && selectedGroup) {
      // Show only messages for selected group
      const filtered = allMessages.filter(msg => 
        msg.isGroup && msg.groupName === selectedGroup
      );
      setMessages(filtered);
    } else {
      setMessages([]);
    }
  }, [recipient, selectedGroup, chatMode, allMessages, username]);

  // Decrypt incoming message
  const decryptIncomingMessage = async (msg: Message, userSecretKey: string): Promise<string> => {
    try {
      if (!msg.encryptedMessage || !msg.kemCiphertext || !msg.iv || !msg.authTag) {
        console.error('Missing encryption data:', {
          hasEncrypted: !!msg.encryptedMessage,
          hasCiphertext: !!msg.kemCiphertext,
          hasIv: !!msg.iv,
          hasAuthTag: !!msg.authTag
        });
        throw new Error('Missing encryption data');
      }

      console.log('🔓 Starting decryption for message from', msg.sender);
      console.log('📊 Encryption data lengths:', {
        encrypted: msg.encryptedMessage?.length || 0,
        ciphertext: msg.kemCiphertext?.length || 0,
        iv: msg.iv?.length || 0,
        authTag: msg.authTag?.length || 0
      });
      
      // Debug: Show the actual base64 strings
      console.log('🔍 Base64 data samples:', {
        encryptedSample: msg.encryptedMessage?.substring(0, 20) + '...',
        ivSample: msg.iv?.substring(0, 20) + '...',
        authTagSample: msg.authTag?.substring(0, 20) + '...'
      });

      // Step 1: Get session key from server by decapsulating KEM
      const response = await fetch('/api/decrypt-kem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kemCiphertext: msg.kemCiphertext,
          secretKey: userSecretKey
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('KEM decapsulation failed:', errorData);
        throw new Error('KEM decapsulation failed');
      }

      const data = await response.json();
      const sessionKeyBase64 = data.sessionKey;
      console.log('✅ Session key received from server');

      // Step 2: Prepare decryption with Web Crypto API
      const sessionKeyBytes = Uint8Array.from(atob(sessionKeyBase64), c => c.charCodeAt(0));
      
      if (sessionKeyBytes.length !== 32) {
        console.error('Invalid session key length:', sessionKeyBytes.length);
        throw new Error('Invalid session key length');
      }

      const cryptoKey = await window.crypto.subtle.importKey(
        'raw',
        sessionKeyBytes,
        { name: 'AES-GCM' },
        false,
        ['decrypt']
      );

      // Step 3: Prepare encrypted data
      // IMPORTANT: The issue is here - we need to handle the format correctly
      const encryptedBytes = Uint8Array.from(atob(msg.encryptedMessage), c => c.charCodeAt(0));
      const ivBytes = Uint8Array.from(atob(msg.iv), c => c.charCodeAt(0));
      const authTagBytes = Uint8Array.from(atob(msg.authTag), c => c.charCodeAt(0));

      console.log('🔧 Decryption components:', {
        encryptedLen: encryptedBytes.length,
        ivLen: ivBytes.length,
        authTagLen: authTagBytes.length,
        sessionKeyLen: sessionKeyBytes.length
      });

      // For Web Crypto API (browser), we need to append auth tag to ciphertext
      // This is different from Node.js where they're separate
      const ciphertextWithTag = new Uint8Array(encryptedBytes.length + authTagBytes.length);
      ciphertextWithTag.set(encryptedBytes, 0);
      ciphertextWithTag.set(authTagBytes, encryptedBytes.length);

      console.log('📦 Combined ciphertext+tag length:', ciphertextWithTag.length);

      // Step 4: Decrypt
      let decrypted;
      try {
        decrypted = await window.crypto.subtle.decrypt(
          {
            name: 'AES-GCM',
            iv: ivBytes
            // Note: tagLength is implicit when tag is appended to ciphertext
          },
          cryptoKey,
          ciphertextWithTag
        );
      } catch (decryptErr) {
        console.error('❌ AES-GCM decryption failed:', decryptErr);
        console.error('This usually means: wrong key, corrupted data, or tampered message');
        throw new Error('AES decryption failed - possible key mismatch');
      }

      const decoder = new TextDecoder();
      const decryptedText = decoder.decode(decrypted);
      console.log('✅ Decryption successful:', decryptedText.substring(0, 20) + '...');
      
      return decryptedText;
    } catch (err) {
      console.error('💥 Decryption error:', err);
      if (err instanceof Error) {
        return `[❌ Decryption Failed: ${err.message}]`;
      }
      return '[❌ Decryption Failed]';
    }
  };

  // SOCKET SETUP
  useEffect(() => {
    const storedUsername = localStorage.getItem('username');
    const storedProfile = localStorage.getItem('profilePicture');
    if (!storedUsername) {
      router.push('/');
      return;
    }
    setUsername(storedUsername);
    if (storedProfile) setProfilePicture(storedProfile);

    const newSocket = io('http://localhost:3000', { transports: ['websocket'] });

    newSocket.on('connect', () => {
      console.log('🟢 Connected:', newSocket.id);
      newSocket.emit('register_user', { username: storedUsername, profilePicture: storedProfile });
      newSocket.emit('get_all_statuses');
    });

    newSocket.on('user_status', (data: { username: string; status: string }) => {
      setUserStatus((prev) => ({ ...prev, [data.username]: data.status }));
    });

    newSocket.on('all_users_status', (statuses: { [key: string]: string }) => {
      setUserStatus(statuses);
    });

    // Handle encrypted private messages
    newSocket.on('receive_encrypted_message', async (data: any) => {
      console.log('📨 Received encrypted message:', {
        from: data.sender,
        to: data.receiver,
        currentUser: storedUsername
      });
      
      // Store ALL messages (don't filter here)
      if (!data.isGroup) {
        // Create unique ID for this message
        const messageId = `${data.sender}-${data.receiver}-${Date.now()}`;
        
        const encMsg: Message = {
          sender: data.sender,
          receiver: data.receiver,
          text: '🔒 [Encrypted - Decrypting...]',
          timestamp: new Date(data.timestamp),
          encryptedMessage: data.encryptedMessage,
          kemCiphertext: data.kemCiphertext,
          iv: data.iv,
          authTag: data.authTag,
          isDecrypted: false,
          decrypting: true,
          imageUrl: data.imageUrl
        };
        
        // Add to ALL messages storage
        setAllMessages(prev => [...prev, encMsg]);
        
        // Wait a bit to ensure state is updated and secret key is loaded
        setTimeout(async () => {
          const userSecretKey = getSecretKey(storedUsername);
          
          console.log('🔍 Decryption check:', {
            currentUser: storedUsername,
            messageSender: data.sender,
            messageReceiver: data.receiver,
            hasSecretKey: !!userSecretKey,
            shouldDecrypt: data.receiver === storedUsername
          });
          
          if (!userSecretKey) {
            console.error('❌ No secret key found for', storedUsername);
            setAllMessages(prev => 
              prev.map(msg => 
                msg.timestamp.getTime() === encMsg.timestamp.getTime() && 
                msg.sender === encMsg.sender && 
                msg.receiver === encMsg.receiver
                  ? { ...msg, text: '⚠️ [No Secret Key - Cannot Decrypt]', decrypting: false }
                  : msg
              )
            );
            return;
          }
          
          try {
            console.log('🔓 Starting decryption for message from', encMsg.sender);
            const decrypted = await decryptIncomingMessage(encMsg, userSecretKey);
            
            // Update the message in allMessages
            setAllMessages(prev => 
              prev.map(msg => 
                msg.timestamp.getTime() === encMsg.timestamp.getTime() && 
                msg.sender === encMsg.sender && 
                msg.receiver === encMsg.receiver
                  ? { ...msg, text: decrypted, isDecrypted: true, decrypting: false }
                  : msg
              )
            );
            console.log('✅ Message decrypted:', decrypted.substring(0, 50));
          } catch (err) {
            console.error('❌ Auto-decryption failed:', err);
            setAllMessages(prev => 
              prev.map(msg => 
                msg.timestamp.getTime() === encMsg.timestamp.getTime() && 
                msg.sender === encMsg.sender && 
                msg.receiver === encMsg.receiver
                  ? { 
                      ...msg, 
                      text: err instanceof Error ? `❌ [${err.message}]` : '❌ [Decryption Failed]',
                      decrypting: false 
                    }
                  : msg
              )
            );
          }
        }, 100); // Small delay to ensure state updates
        
        // Show notification if not in the current chat
        const isCurrentChat = 
          (data.sender === recipient && data.receiver === storedUsername) ||
          (data.sender === storedUsername && data.receiver === recipient);
        
        if (!isCurrentChat && data.sender !== storedUsername) {
          setNotifications(prev => [{
            sender: data.sender,
            message: 'New encrypted message',
            timestamp: new Date()
          }, ...prev]);
        }
      }
    });

    // Handle group messages
    newSocket.on('receive_group_message', (data: Message) => {
      if (data.isGroup) {
        setAllMessages(prev => [...prev, { ...data, isGroup: true }]);
      }
    });

    newSocket.on('notification', (data: { sender: string; message: string }) => {
      const notif = { sender: data.sender, message: data.message, timestamp: new Date() };
      setNotifications((prev) => [notif, ...prev]);
    });

    newSocket.on('group_created', (data: { groupName: string }) => setGroups((prev) => [...prev, data.groupName]));
    newSocket.on('all_groups', (data: string[]) => setGroups(data));
    newSocket.on('group_members', (data: { groupName: string; members: string[] }) => {
      if (selectedGroup === data.groupName) setGroupMembers(data.members);
    });

    newSocket.on('user_typing', (data: { sender: string }) => {
      setTypingUser(data.sender);
      setIsTyping(true);
    });

    newSocket.on('user_stopped_typing', () => {
      setIsTyping(false);
      setTypingUser('');
    });

    setSocket(newSocket);
    return () => {
      newSocket.close();
    };
  }, [router]);

  const handleCreateGroup = () => {
    if (!socket || !newGroupName.trim()) return;
    socket.emit('create_group', { groupName: newGroupName.trim(), creator: username });
    setSelectedGroup(newGroupName.trim());
    socket.emit('join_group', { groupName: newGroupName.trim(), username });
    setNewGroupName('');
    setShowCreateGroup(false);
    setChatMode('group');
  };

  const handleJoinGroup = (groupName: string) => {
    if (!socket) return;
    setSelectedGroup(groupName);
    socket.emit('join_group', { groupName, username });
    setChatMode('group');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', 'message');
    try {
      const res = await fetch('/api/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (data.url) sendMessageWithImage(data.url);
    } catch (err) {
      console.error('Upload failed:', err);
    }
  };

  const sendMessageWithImage = (imageUrl: string) => {
    if (!socket) return;
    
    if (chatMode === 'private' && !recipient.trim()) {
      alert('Please enter a recipient username');
      return;
    }
    
    if (chatMode === 'group' && !selectedGroup) {
      alert('Please select a group first');
      return;
    }

    const msg: Message = {
      sender: username,
      receiver: chatMode === 'private' ? recipient : undefined,
      groupName: chatMode === 'group' ? selectedGroup : undefined,
      text: message.trim(),
      imageUrl,
      isGroup: chatMode === 'group',
      timestamp: new Date()
    };
    socket.emit(chatMode === 'private' ? 'send_message' : 'send_group_message', msg);
    setMessage('');
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!socket || !message.trim()) return;
    
    if (chatMode === 'private' && !recipient.trim()) {
      alert('Please enter a recipient username');
      return;
    }
    
    if (chatMode === 'group' && !selectedGroup) {
      alert('Please select a group first');
      return;
    }

    const msg: Message = {
      sender: username,
      receiver: chatMode === 'private' ? recipient : undefined,
      groupName: chatMode === 'group' ? selectedGroup : undefined,
      text: message.trim(),
      isGroup: chatMode === 'group',
      timestamp: new Date()
    };

    console.log('📤 Sending message:', msg);
    socket.emit(chatMode === 'private' ? 'send_message' : 'send_group_message', msg);
    setMessage('');
  };

  const handleTyping = () => {
    if (!socket) return;
    if (chatMode === 'private' && recipient) socket.emit('typing', { sender: username, receiver: recipient });
    else if (chatMode === 'group' && selectedGroup) socket.emit('typing_group', { groupName: selectedGroup, sender: username });
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      if (chatMode === 'private' && recipient) socket.emit('stop_typing', { sender: username, receiver: recipient });
      else if (chatMode === 'group' && selectedGroup) socket.emit('stop_typing_group', { groupName: selectedGroup, sender: username });
    }, 1000);
  };

  const handleLogout = () => {
    clearSecretKey(username);
    localStorage.removeItem('username');
    localStorage.removeItem('profilePicture');
    socket?.close();
    router.push('/');
  };

  const getRecipientStatus = () => {
    if (!recipient || !userStatus) return false;
    return userStatus[recipient]?.toLowerCase() === 'online';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col">
      <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />

      {/* HEADER */}
      <div className="bg-black/40 backdrop-blur-xl border-b border-white/10 shadow-2xl">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full overflow-hidden flex items-center justify-center">
              {profilePicture ? <img src={profilePicture} alt="Profile" className="w-full h-full object-cover" /> : <span className="text-2xl">👤</span>}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">ChatVerse 🔐</h1>
              <p className="text-xs text-purple-300">
                {username} {hasKeyLoaded ? '• 🔑 Key Loaded' : '• ⚠️ No Key'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => setShowNotifications(!showNotifications)} className="relative bg-white/10 border border-white/20 text-white px-4 py-2 rounded-full hover:bg-white/20 transition">
              🔔
              {notifications.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {notifications.length}
                </span>
              )}
            </button>

            <div className="flex bg-white/10 rounded-full p-1 border border-white/20">
              <button onClick={() => setChatMode('private')} className={`px-4 py-2 rounded-full transition ${chatMode === 'private' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-white/60 hover:text-white'}`}>👤 Private</button>
              <button onClick={() => setChatMode('group')} className={`px-4 py-2 rounded-full transition ${chatMode === 'group' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-white/60 hover:text-white'}`}>👥 Group</button>
            </div>

            <button onClick={handleLogout} className="bg-red-500/20 border border-red-500/50 text-red-300 px-6 py-2 rounded-full hover:bg-red-500/30 transition font-semibold">Logout</button>
          </div>
        </div>
      </div>

      {/* NOTIFICATIONS DROPDOWN */}
      {showNotifications && (
        <div className="absolute top-20 right-4 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/20 w-80 max-h-96 overflow-y-auto z-50">
          <h3 className="font-bold text-lg mb-3 text-gray-800">Notifications</h3>
          {notifications.length === 0 ? (
            <p className="text-gray-500 text-sm">No notifications</p>
          ) : (
            notifications.map((notif, idx) => (
              <div key={idx} className="bg-purple-50 p-3 rounded-lg mb-2">
                <p className="font-semibold text-sm text-gray-800">{notif.sender}</p>
                <p className="text-xs text-gray-600">{notif.message}</p>
                <p className="text-xs text-gray-400 mt-1">{new Date(notif.timestamp).toLocaleTimeString()}</p>
              </div>
            ))
          )}
        </div>
      )}

      {/* CHAT AREA */}
      <div className="container mx-auto flex-1 p-4 flex gap-4 max-w-7xl">
        {chatMode === 'group' && (
          <div className="w-80 bg-white/10 rounded-3xl p-6 border border-white/20 flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">Groups</h2>
              <button onClick={() => setShowCreateGroup(!showCreateGroup)} className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white w-10 h-10 rounded-full font-bold text-xl hover:scale-110 transition">+</button>
            </div>

            {showCreateGroup && (
              <div className="mb-4 space-y-2">
                <input type="text" value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} placeholder="Group name" className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50" />
                <button onClick={handleCreateGroup} className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-full font-semibold hover:scale-105 transition">Create</button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto space-y-2">
              {groups.length === 0 ? (
                <p className="text-white/50 text-sm text-center mt-4">No groups yet</p>
              ) : (
                groups.map((group, i) => (
                  <button key={i} onClick={() => handleJoinGroup(group)} className={`w-full p-4 rounded-2xl transition ${selectedGroup === group ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'bg-white/5 text-white hover:bg-white/10'}`}>
                    👥 {group}
                  </button>
                ))
              )}
            </div>
          </div>
        )}

        {/* MAIN CHAT BOX */}
        <div className="flex-1 flex flex-col">
          {chatMode === 'private' && (
            <div className="bg-white/10 p-6 rounded-3xl mb-4 border border-white/20">
              <label className="block text-lg font-semibold text-white mb-3">🎯 Chat with</label>
              <div className="flex gap-3 items-center">
                <input 
                  type="text" 
                  value={recipient} 
                  onChange={(e) => setRecipient(e.target.value)} 
                  placeholder="Enter recipient's username" 
                  className="flex-1 px-6 py-3 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50" 
                />
                {recipient && (
                  <div className="flex items-center gap-2 bg-white/10 px-4 py-3 rounded-full border border-white/20">
                    <div className={`w-3 h-3 rounded-full ${getRecipientStatus() ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`} />
                    <span className={`text-sm font-semibold ${getRecipientStatus() ? 'text-green-300' : 'text-gray-400'}`}>
                      {getRecipientStatus() ? 'Online' : 'Offline'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {chatMode === 'group' && selectedGroup && (
            <div className="bg-white/10 p-4 rounded-3xl mb-4 border border-white/20">
              <h3 className="text-lg font-bold text-white">👥 {selectedGroup}</h3>
              <p className="text-sm text-white/60">Group Chat</p>
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 bg-white/5 rounded-3xl overflow-y-auto p-6 space-y-4 relative">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <p className="text-white/40 text-lg">
                  {chatMode === 'private' 
                    ? recipient 
                      ? '🔐 Start secure chatting!'
                      : '🔐 Enter a recipient username to start chatting'
                    : 'Select a group to start chatting'}
                </p>
              </div>
            ) : (
              messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.sender === username ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-md px-6 py-3 rounded-3xl shadow-lg ${msg.sender === username ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'bg-white/10 text-white'} border border-white/20`}>
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-xs font-semibold opacity-80">{msg.sender}</p>
                      {msg.decrypting && (
                        <span className="text-xs bg-yellow-500/30 px-2 py-1 rounded-full animate-pulse">🔄 Decrypting...</span>
                      )}
                      {msg.isDecrypted && (
                        <span className="text-xs bg-green-500/30 px-2 py-1 rounded-full">✅ Decrypted</span>
                      )}
                      {!msg.isDecrypted && msg.encryptedMessage && !msg.decrypting && (
                        <span className="text-xs bg-red-500/30 px-2 py-1 rounded-full">🔒 Encrypted</span>
                      )}
                    </div>
                    {msg.imageUrl && <img src={msg.imageUrl} alt="img" className="rounded-lg mb-2 max-w-xs" />}
                    <p className="break-words">{msg.text}</p>
                    <p className="text-xs mt-2 opacity-60">{new Date(msg.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              ))
            )}
            {isTyping && typingUser && typingUser === recipient && (
              <div className="flex justify-start">
                <div className="bg-white/10 px-4 py-2 rounded-full">
                  <p className="text-sm text-white/70">{typingUser} is typing...</p>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Emoji Picker */}
          {showEmojiPicker && (
            <div className="absolute bottom-24 left-6 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/20 grid grid-cols-10 gap-2 z-50">
              {emojis.map((emoji, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => {
                    setMessage((prev) => prev + emoji);
                    setShowEmojiPicker(false);
                  }}
                  className="text-2xl hover:bg-purple-100 rounded-lg p-2 transition"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <form onSubmit={handleSendMessage} className="p-4 bg-black/20 border-t border-white/10 flex gap-3">
            <button type="button" onClick={() => setShowEmojiPicker(!showEmojiPicker)} className="bg-white/10 text-white px-4 py-4 rounded-full hover:bg-white/20 transition">😊</button>
            <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-white/10 text-white px-4 py-4 rounded-full hover:bg-white/20 transition">📎</button>
            <input
              type="text"
              value={message}
              onChange={(e) => {
                setMessage(e.target.value);
                handleTyping();
              }}
              placeholder="Type a message..."
              className="flex-1 px-6 py-4 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
            />
            <button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:scale-105 transition">
              Send →
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

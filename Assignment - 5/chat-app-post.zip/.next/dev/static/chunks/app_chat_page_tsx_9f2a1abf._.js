(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/chat/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/socket.io-client/build/esm/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const emojis = [
    '😀',
    '😂',
    '😍',
    '🥰',
    '😎',
    '🤔',
    '😭',
    '😱',
    '🔥',
    '💯',
    '👍',
    '👎',
    '❤️',
    '💔',
    '🎉',
    '🎊',
    '✨',
    '⭐',
    '🌟',
    '💫'
];
function ChatPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(141);
    if ($[0] !== "eac56f5be4378a0d2daa84217f512c4b78bc286ba3ec23ad0aa1c671760b8028") {
        for(let $i = 0; $i < 141; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "eac56f5be4378a0d2daa84217f512c4b78bc286ba3ec23ad0aa1c671760b8028";
    }
    const [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [profilePicture, setProfilePicture] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [recipient, setRecipient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    const [socket, setSocket] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isTyping, setIsTyping] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {};
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [userStatus, setUserStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [showEmojiPicker, setShowEmojiPicker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [typingUser, setTypingUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [chatMode, setChatMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("private");
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [groups, setGroups] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    const [selectedGroup, setSelectedGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    const [showNotifications, setShowNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [, setNotificationPermission] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("default");
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {};
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    const [newGroupName, setNewGroupName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showCreateGroup, setShowCreateGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [];
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const [, setGroupMembers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t5);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const typingTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ChatPage[scrollToBottom]": ()=>messagesEndRef.current?.scrollIntoView({
                    behavior: "smooth"
                })
        })["ChatPage[scrollToBottom]"];
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const scrollToBottom = t6;
    let t7;
    if ($[8] !== messages) {
        t7 = [
            messages
        ];
        $[8] = messages;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(scrollToBottom, t7);
    let t8;
    let t9;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "ChatPage[useEffect()]": ()=>{
                if ("Notification" in window) {
                    setNotificationPermission(Notification.permission);
                }
            }
        })["ChatPage[useEffect()]"];
        t9 = [];
        $[10] = t8;
        $[11] = t9;
    } else {
        t8 = $[10];
        t9 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t8, t9);
    let t10;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "ChatPage[useEffect()]": ()=>{
                setMessages([]);
            }
        })["ChatPage[useEffect()]"];
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== chatMode || $[14] !== recipient || $[15] !== selectedGroup) {
        t11 = [
            chatMode,
            recipient,
            selectedGroup
        ];
        $[13] = chatMode;
        $[14] = recipient;
        $[15] = selectedGroup;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t10, t11);
    let t12;
    let t13;
    if ($[17] !== router || $[18] !== selectedGroup) {
        t12 = ({
            "ChatPage[useEffect()]": ()=>{
                const storedUsername = localStorage.getItem("username");
                const storedProfile = localStorage.getItem("profilePicture");
                if (!storedUsername) {
                    router.push("/");
                    return;
                }
                setUsername(storedUsername);
                if (storedProfile) {
                    setProfilePicture(storedProfile);
                }
                const newSocket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])("http://localhost:3000", {
                    transports: [
                        "websocket"
                    ]
                });
                newSocket.on("connect", {
                    "ChatPage[useEffect() > newSocket.on()]": ()=>{
                        console.log("\uD83D\uDFE2 Connected:", newSocket.id);
                        newSocket.emit("register_user", {
                            username: storedUsername,
                            profilePicture: storedProfile
                        });
                        newSocket.emit("get_all_statuses");
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("user_status", {
                    "ChatPage[useEffect() > newSocket.on()]": (data)=>{
                        setUserStatus({
                            "ChatPage[useEffect() > newSocket.on() > setUserStatus()]": (prev)=>({
                                    ...prev,
                                    [data.username]: data.status
                                })
                        }["ChatPage[useEffect() > newSocket.on() > setUserStatus()]"]);
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("all_users_status", {
                    "ChatPage[useEffect() > newSocket.on()]": (statuses)=>{
                        console.log("\uD83D\uDCE1 Received all statuses:", statuses);
                        setUserStatus(statuses);
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("receive_message", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_0)=>{
                        if (!data_0.isGroup) {
                            setMessages({
                                "ChatPage[useEffect() > newSocket.on() > setMessages()]": (prev_0)=>[
                                        ...prev_0,
                                        data_0
                                    ]
                            }["ChatPage[useEffect() > newSocket.on() > setMessages()]"]);
                        }
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("receive_group_message", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_1)=>{
                        if (data_1.isGroup && data_1.groupName === selectedGroup) {
                            setMessages({
                                "ChatPage[useEffect() > newSocket.on() > setMessages()]": (prev_1)=>[
                                        ...prev_1,
                                        {
                                            ...data_1,
                                            isGroup: true
                                        }
                                    ]
                            }["ChatPage[useEffect() > newSocket.on() > setMessages()]"]);
                        }
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("notification", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_2)=>{
                        const notif = {
                            sender: data_2.sender,
                            message: data_2.message,
                            timestamp: new Date()
                        };
                        setNotifications({
                            "ChatPage[useEffect() > newSocket.on() > setNotifications()]": (prev_2)=>[
                                    notif,
                                    ...prev_2
                                ]
                        }["ChatPage[useEffect() > newSocket.on() > setNotifications()]"]);
                        if ("Notification" in window && Notification.permission === "granted") {
                            new Notification(`New message from ${data_2.sender}`, {
                                body: data_2.message,
                                icon: "/profiles/default.png"
                            });
                        }
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("group_created", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_3)=>setGroups({
                            "ChatPage[useEffect() > newSocket.on() > setGroups()]": (prev_3)=>[
                                    ...prev_3,
                                    data_3.groupName
                                ]
                        }["ChatPage[useEffect() > newSocket.on() > setGroups()]"])
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("all_groups", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_4)=>setGroups(data_4)
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("group_members", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_5)=>{
                        if (selectedGroup === data_5.groupName) {
                            setGroupMembers(data_5.members);
                        }
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("user_typing", {
                    "ChatPage[useEffect() > newSocket.on()]": (data_6)=>{
                        setTypingUser(data_6.sender);
                        setIsTyping(true);
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                newSocket.on("user_stopped_typing", {
                    "ChatPage[useEffect() > newSocket.on()]": ()=>{
                        setIsTyping(false);
                        setTypingUser("");
                    }
                }["ChatPage[useEffect() > newSocket.on()]"]);
                setSocket(newSocket);
                return ()=>{
                    newSocket.close();
                };
            }
        })["ChatPage[useEffect()]"];
        t13 = [
            router,
            selectedGroup
        ];
        $[17] = router;
        $[18] = selectedGroup;
        $[19] = t12;
        $[20] = t13;
    } else {
        t12 = $[19];
        t13 = $[20];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t12, t13);
    let t14;
    if ($[21] !== newGroupName || $[22] !== socket || $[23] !== username) {
        t14 = ({
            "ChatPage[handleCreateGroup]": ()=>{
                if (!socket || !newGroupName.trim()) {
                    return;
                }
                socket.emit("create_group", {
                    groupName: newGroupName.trim(),
                    creator: username
                });
                setSelectedGroup(newGroupName.trim());
                socket.emit("join_group", {
                    groupName: newGroupName.trim(),
                    username
                });
                setNewGroupName("");
                setShowCreateGroup(false);
                setChatMode("group");
            }
        })["ChatPage[handleCreateGroup]"];
        $[21] = newGroupName;
        $[22] = socket;
        $[23] = username;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    const handleCreateGroup = t14;
    let t15;
    if ($[25] !== socket || $[26] !== username) {
        t15 = ({
            "ChatPage[handleJoinGroup]": (groupName)=>{
                if (!socket) {
                    return;
                }
                setSelectedGroup(groupName);
                socket.emit("join_group", {
                    groupName,
                    username
                });
                setChatMode("group");
                setMessages([]);
            }
        })["ChatPage[handleJoinGroup]"];
        $[25] = socket;
        $[26] = username;
        $[27] = t15;
    } else {
        t15 = $[27];
    }
    const handleJoinGroup = t15;
    let handleFileUpload;
    let t16;
    if ($[28] !== chatMode || $[29] !== message || $[30] !== recipient || $[31] !== selectedGroup || $[32] !== socket || $[33] !== username) {
        handleFileUpload = ({
            "ChatPage[handleFileUpload]": async (e)=>{
                const file = e.target.files?.[0];
                if (!file) {
                    return;
                }
                const formData = new FormData();
                formData.append("file", file);
                formData.append("type", "message");
                ;
                try {
                    const res = await fetch("/api/upload", {
                        method: "POST",
                        body: formData
                    });
                    const data_7 = await res.json();
                    if (data_7.url) {
                        sendMessageWithImage(data_7.url);
                    }
                } catch (t17) {
                    const err = t17;
                    console.error("Upload failed:", err);
                }
            }
        })["ChatPage[handleFileUpload]"];
        const sendMessageWithImage = {
            "ChatPage[sendMessageWithImage]": (imageUrl)=>{
                if (!socket) {
                    return;
                }
                if (chatMode === "private" && !recipient.trim()) {
                    alert("Please enter a recipient username");
                    return;
                }
                if (chatMode === "group" && !selectedGroup) {
                    alert("Please select a group first");
                    return;
                }
                const msg = {
                    sender: username,
                    receiver: chatMode === "private" ? recipient : undefined,
                    groupName: chatMode === "group" ? selectedGroup : undefined,
                    text: message.trim(),
                    imageUrl,
                    isGroup: chatMode === "group",
                    timestamp: new Date()
                };
                socket.emit(chatMode === "private" ? "send_message" : "send_group_message", msg);
                setMessage("");
            }
        }["ChatPage[sendMessageWithImage]"];
        t16 = ({
            "ChatPage[handleSendMessage]": (e_0)=>{
                e_0.preventDefault();
                if (!socket || !message.trim()) {
                    return;
                }
                if (chatMode === "private" && !recipient.trim()) {
                    alert("Please enter a recipient username");
                    return;
                }
                if (chatMode === "group" && !selectedGroup) {
                    alert("Please select a group first");
                    return;
                }
                const msg_0 = {
                    sender: username,
                    receiver: chatMode === "private" ? recipient : undefined,
                    groupName: chatMode === "group" ? selectedGroup : undefined,
                    text: message.trim(),
                    isGroup: chatMode === "group",
                    timestamp: new Date()
                };
                socket.emit(chatMode === "private" ? "send_message" : "send_group_message", msg_0);
                setMessage("");
            }
        })["ChatPage[handleSendMessage]"];
        $[28] = chatMode;
        $[29] = message;
        $[30] = recipient;
        $[31] = selectedGroup;
        $[32] = socket;
        $[33] = username;
        $[34] = handleFileUpload;
        $[35] = t16;
    } else {
        handleFileUpload = $[34];
        t16 = $[35];
    }
    const handleSendMessage = t16;
    let t17;
    if ($[36] !== chatMode || $[37] !== recipient || $[38] !== selectedGroup || $[39] !== socket || $[40] !== username) {
        t17 = ({
            "ChatPage[handleTyping]": ()=>{
                if (!socket) {
                    return;
                }
                if (chatMode === "private" && recipient) {
                    socket.emit("typing", {
                        sender: username,
                        receiver: recipient
                    });
                } else {
                    if (chatMode === "group" && selectedGroup) {
                        socket.emit("typing_group", {
                            groupName: selectedGroup,
                            sender: username
                        });
                    }
                }
                if (typingTimeoutRef.current) {
                    clearTimeout(typingTimeoutRef.current);
                }
                typingTimeoutRef.current = setTimeout({
                    "ChatPage[handleTyping > setTimeout()]": ()=>{
                        if (chatMode === "private" && recipient) {
                            socket.emit("stop_typing", {
                                sender: username,
                                receiver: recipient
                            });
                        } else {
                            if (chatMode === "group" && selectedGroup) {
                                socket.emit("stop_typing_group", {
                                    groupName: selectedGroup,
                                    sender: username
                                });
                            }
                        }
                    }
                }["ChatPage[handleTyping > setTimeout()]"], 1000);
            }
        })["ChatPage[handleTyping]"];
        $[36] = chatMode;
        $[37] = recipient;
        $[38] = selectedGroup;
        $[39] = socket;
        $[40] = username;
        $[41] = t17;
    } else {
        t17 = $[41];
    }
    const handleTyping = t17;
    let t18;
    if ($[42] !== router || $[43] !== socket) {
        t18 = ({
            "ChatPage[handleLogout]": ()=>{
                localStorage.removeItem("username");
                localStorage.removeItem("profilePicture");
                socket?.close();
                router.push("/");
            }
        })["ChatPage[handleLogout]"];
        $[42] = router;
        $[43] = socket;
        $[44] = t18;
    } else {
        t18 = $[44];
    }
    const handleLogout = t18;
    let t19;
    if ($[45] !== recipient || $[46] !== userStatus) {
        t19 = ({
            "ChatPage[getRecipientStatus]": ()=>{
                if (!recipient || !userStatus) {
                    return false;
                }
                return userStatus[recipient]?.toLowerCase() === "online";
            }
        })["ChatPage[getRecipientStatus]"];
        $[45] = recipient;
        $[46] = userStatus;
        $[47] = t19;
    } else {
        t19 = $[47];
    }
    const getRecipientStatus = t19;
    let t20;
    if ($[48] !== handleFileUpload) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "file",
            ref: fileInputRef,
            onChange: handleFileUpload,
            accept: "image/*",
            className: "hidden"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 516,
            columnNumber: 11
        }, this);
        $[48] = handleFileUpload;
        $[49] = t20;
    } else {
        t20 = $[49];
    }
    let t21;
    if ($[50] !== profilePicture) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full overflow-hidden flex items-center justify-center",
            children: profilePicture ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: profilePicture,
                alt: "Profile",
                className: "w-full h-full object-cover"
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 524,
                columnNumber: 166
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-2xl",
                children: "👤"
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 524,
                columnNumber: 250
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 524,
            columnNumber: 11
        }, this);
        $[50] = profilePicture;
        $[51] = t21;
    } else {
        t21 = $[51];
    }
    let t22;
    if ($[52] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-2xl font-bold text-white",
            children: "ChatVerse"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 532,
            columnNumber: 11
        }, this);
        $[52] = t22;
    } else {
        t22 = $[52];
    }
    let t23;
    if ($[53] !== username) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t22,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs text-purple-300",
                    children: [
                        "Connected as ",
                        username
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 539,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 539,
            columnNumber: 11
        }, this);
        $[53] = username;
        $[54] = t23;
    } else {
        t23 = $[54];
    }
    let t24;
    if ($[55] !== t21 || $[56] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-3",
            children: [
                t21,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 547,
            columnNumber: 11
        }, this);
        $[55] = t21;
        $[56] = t23;
        $[57] = t24;
    } else {
        t24 = $[57];
    }
    let t25;
    if ($[58] !== showNotifications) {
        t25 = ({
            "ChatPage[<button>.onClick]": ()=>setShowNotifications(!showNotifications)
        })["ChatPage[<button>.onClick]"];
        $[58] = showNotifications;
        $[59] = t25;
    } else {
        t25 = $[59];
    }
    let t26;
    if ($[60] !== notifications.length) {
        t26 = notifications.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center",
            children: notifications.length
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 566,
            columnNumber: 39
        }, this);
        $[60] = notifications.length;
        $[61] = t26;
    } else {
        t26 = $[61];
    }
    let t27;
    if ($[62] !== t25 || $[63] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t25,
            className: "relative bg-white/10 border border-white/20 text-white px-4 py-2 rounded-full hover:bg-white/20 transition",
            children: [
                "🔔",
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 574,
            columnNumber: 11
        }, this);
        $[62] = t25;
        $[63] = t26;
        $[64] = t27;
    } else {
        t27 = $[64];
    }
    let t28;
    if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = ({
            "ChatPage[<button>.onClick]": ()=>setChatMode("private")
        })["ChatPage[<button>.onClick]"];
        $[65] = t28;
    } else {
        t28 = $[65];
    }
    const t29 = `px-4 py-2 rounded-full transition ${chatMode === "private" ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white" : "text-white/60 hover:text-white"}`;
    let t30;
    if ($[66] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t28,
            className: t29,
            children: "👤 Private"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 593,
            columnNumber: 11
        }, this);
        $[66] = t29;
        $[67] = t30;
    } else {
        t30 = $[67];
    }
    let t31;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = ({
            "ChatPage[<button>.onClick]": ()=>setChatMode("group")
        })["ChatPage[<button>.onClick]"];
        $[68] = t31;
    } else {
        t31 = $[68];
    }
    const t32 = `px-4 py-2 rounded-full transition ${chatMode === "group" ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white" : "text-white/60 hover:text-white"}`;
    let t33;
    if ($[69] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t31,
            className: t32,
            children: "👥 Group"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 611,
            columnNumber: 11
        }, this);
        $[69] = t32;
        $[70] = t33;
    } else {
        t33 = $[70];
    }
    let t34;
    if ($[71] !== t30 || $[72] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex bg-white/10 rounded-full p-1 border border-white/20",
            children: [
                t30,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 619,
            columnNumber: 11
        }, this);
        $[71] = t30;
        $[72] = t33;
        $[73] = t34;
    } else {
        t34 = $[73];
    }
    let t35;
    if ($[74] !== handleLogout) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: handleLogout,
            className: "bg-red-500/20 border border-red-500/50 text-red-300 px-6 py-2 rounded-full hover:bg-red-500/30 transition font-semibold",
            children: "Logout"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 628,
            columnNumber: 11
        }, this);
        $[74] = handleLogout;
        $[75] = t35;
    } else {
        t35 = $[75];
    }
    let t36;
    if ($[76] !== t27 || $[77] !== t34 || $[78] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-3",
            children: [
                t27,
                t34,
                t35
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 636,
            columnNumber: 11
        }, this);
        $[76] = t27;
        $[77] = t34;
        $[78] = t35;
        $[79] = t36;
    } else {
        t36 = $[79];
    }
    let t37;
    if ($[80] !== t24 || $[81] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-black/40 backdrop-blur-xl border-b border-white/10 shadow-2xl",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 py-4 flex justify-between items-center",
                children: [
                    t24,
                    t36
                ]
            }, void 0, true, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 646,
                columnNumber: 93
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 646,
            columnNumber: 11
        }, this);
        $[80] = t24;
        $[81] = t36;
        $[82] = t37;
    } else {
        t37 = $[82];
    }
    let t38;
    if ($[83] !== notifications || $[84] !== showNotifications) {
        t38 = showNotifications && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-20 right-4 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/20 w-80 max-h-96 overflow-y-auto z-50",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "font-bold text-lg mb-3 text-gray-800",
                    children: "Notifications"
                }, void 0, false, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 655,
                    columnNumber: 187
                }, this),
                notifications.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-500 text-sm",
                    children: "No notifications"
                }, void 0, false, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 655,
                    columnNumber: 288
                }, this) : notifications.map(_ChatPageNotificationsMap)
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 655,
            columnNumber: 32
        }, this);
        $[83] = notifications;
        $[84] = showNotifications;
        $[85] = t38;
    } else {
        t38 = $[85];
    }
    let t39;
    if ($[86] !== chatMode || $[87] !== groups || $[88] !== handleCreateGroup || $[89] !== handleJoinGroup || $[90] !== newGroupName || $[91] !== selectedGroup || $[92] !== showCreateGroup) {
        t39 = chatMode === "group" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-80 bg-white/10 rounded-3xl p-6 border border-white/20 flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-bold text-white",
                            children: "Groups"
                        }, void 0, false, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 664,
                            columnNumber: 178
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: {
                                "ChatPage[<button>.onClick]": ()=>setShowCreateGroup(!showCreateGroup)
                            }["ChatPage[<button>.onClick]"],
                            className: "bg-gradient-to-r from-indigo-600 to-purple-600 text-white w-10 h-10 rounded-full font-bold text-xl hover:scale-110 transition",
                            children: "+"
                        }, void 0, false, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 664,
                            columnNumber: 234
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 664,
                    columnNumber: 122
                }, this),
                showCreateGroup && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4 space-y-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: newGroupName,
                            onChange: {
                                "ChatPage[<input>.onChange]": (e_1)=>setNewGroupName(e_1.target.value)
                            }["ChatPage[<input>.onChange]"],
                            placeholder: "Group name",
                            className: "w-full px-4 py-2 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
                        }, void 0, false, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 666,
                            columnNumber: 248
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleCreateGroup,
                            className: "w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-full font-semibold hover:scale-105 transition",
                            children: "Create"
                        }, void 0, false, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 668,
                            columnNumber: 178
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 666,
                    columnNumber: 216
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto space-y-2",
                    children: groups.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-white/50 text-sm text-center mt-4",
                        children: "No groups yet"
                    }, void 0, false, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 668,
                        columnNumber: 445
                    }, this) : groups.map({
                        "ChatPage[groups.map()]": (group, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: {
                                    "ChatPage[groups.map() > <button>.onClick]": ()=>handleJoinGroup(group)
                                }["ChatPage[groups.map() > <button>.onClick]"],
                                className: `w-full p-4 rounded-2xl transition ${selectedGroup === group ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white" : "bg-white/5 text-white hover:bg-white/10"}`,
                                children: [
                                    "👥 ",
                                    group
                                ]
                            }, i, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 669,
                                columnNumber: 51
                            }, this)
                    }["ChatPage[groups.map()]"])
                }, void 0, false, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 668,
                    columnNumber: 372
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 664,
            columnNumber: 35
        }, this);
        $[86] = chatMode;
        $[87] = groups;
        $[88] = handleCreateGroup;
        $[89] = handleJoinGroup;
        $[90] = newGroupName;
        $[91] = selectedGroup;
        $[92] = showCreateGroup;
        $[93] = t39;
    } else {
        t39 = $[93];
    }
    let t40;
    if ($[94] !== chatMode || $[95] !== getRecipientStatus || $[96] !== recipient) {
        t40 = chatMode === "private" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white/10 p-6 rounded-3xl mb-4 border border-white/20",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-lg font-semibold text-white mb-3",
                    children: "🎯 Chat with"
                }, void 0, false, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 686,
                    columnNumber: 110
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: recipient,
                            onChange: {
                                "ChatPage[<input>.onChange]": (e_2)=>setRecipient(e_2.target.value)
                            }["ChatPage[<input>.onChange]"],
                            placeholder: "Enter recipient's username",
                            className: "flex-1 px-6 py-3 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
                        }, void 0, false, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 686,
                            columnNumber: 234
                        }, this),
                        recipient && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 bg-white/10 px-4 py-3 rounded-full border border-white/20",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-3 h-3 rounded-full ${getRecipientStatus() ? "bg-green-400 animate-pulse" : "bg-gray-400"}`
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 688,
                                    columnNumber: 307
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `text-sm font-semibold ${getRecipientStatus() ? "text-green-300" : "text-gray-400"}`,
                                    children: getRecipientStatus() ? "Online" : "Offline"
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 688,
                                    columnNumber: 420
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 688,
                            columnNumber: 208
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 686,
                    columnNumber: 193
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 686,
            columnNumber: 37
        }, this);
        $[94] = chatMode;
        $[95] = getRecipientStatus;
        $[96] = recipient;
        $[97] = t40;
    } else {
        t40 = $[97];
    }
    let t41;
    if ($[98] !== chatMode || $[99] !== selectedGroup) {
        t41 = chatMode === "group" && selectedGroup && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white/10 p-4 rounded-3xl mb-4 border border-white/20",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-lg font-bold text-white",
                    children: [
                        "👥 ",
                        selectedGroup
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 698,
                    columnNumber: 125
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-white/60",
                    children: "Group Chat"
                }, void 0, false, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 698,
                    columnNumber: 193
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 698,
            columnNumber: 52
        }, this);
        $[98] = chatMode;
        $[99] = selectedGroup;
        $[100] = t41;
    } else {
        t41 = $[100];
    }
    let t42;
    if ($[101] !== chatMode || $[102] !== messages || $[103] !== username) {
        t42 = messages.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center h-full",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-white/40 text-lg",
                children: chatMode === "private" ? "Start chatting by selecting a recipient" : "Select a group to start chatting"
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 707,
                columnNumber: 92
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 707,
            columnNumber: 35
        }, this) : messages.map({
            "ChatPage[messages.map()]": (msg_1, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `flex ${msg_1.sender === username ? "justify-end" : "justify-start"}`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `max-w-md px-6 py-3 rounded-3xl shadow-lg ${msg_1.sender === username ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white" : "bg-white/10 text-white"} border border-white/20`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold mb-1 opacity-80",
                                children: msg_1.sender
                            }, void 0, false, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 708,
                                columnNumber: 349
                            }, this),
                            msg_1.imageUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: msg_1.imageUrl,
                                alt: "img",
                                className: "rounded-lg mb-2 max-w-xs"
                            }, void 0, false, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 708,
                                columnNumber: 439
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "break-words",
                                children: msg_1.text
                            }, void 0, false, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 708,
                                columnNumber: 515
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs mt-2 opacity-60",
                                children: new Date(msg_1.timestamp).toLocaleTimeString()
                            }, void 0, false, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 708,
                                columnNumber: 558
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 708,
                        columnNumber: 148
                    }, this)
                }, i_0, false, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 708,
                    columnNumber: 51
                }, this)
        }["ChatPage[messages.map()]"]);
        $[101] = chatMode;
        $[102] = messages;
        $[103] = username;
        $[104] = t42;
    } else {
        t42 = $[104];
    }
    let t43;
    if ($[105] !== isTyping || $[106] !== typingUser) {
        t43 = isTyping && typingUser && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-start",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white/10 px-4 py-2 rounded-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-white/70",
                    children: [
                        typingUser,
                        " is typing..."
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 719,
                    columnNumber: 125
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 719,
                columnNumber: 73
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 719,
            columnNumber: 37
        }, this);
        $[105] = isTyping;
        $[106] = typingUser;
        $[107] = t43;
    } else {
        t43 = $[107];
    }
    let t44;
    if ($[108] === Symbol.for("react.memo_cache_sentinel")) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: messagesEndRef
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 728,
            columnNumber: 11
        }, this);
        $[108] = t44;
    } else {
        t44 = $[108];
    }
    let t45;
    if ($[109] !== t42 || $[110] !== t43) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 bg-white/5 rounded-3xl overflow-y-auto p-6 space-y-4 relative",
            children: [
                t42,
                t43,
                t44
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 735,
            columnNumber: 11
        }, this);
        $[109] = t42;
        $[110] = t43;
        $[111] = t45;
    } else {
        t45 = $[111];
    }
    let t46;
    if ($[112] !== showEmojiPicker) {
        t46 = showEmojiPicker && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute bottom-24 left-6 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/20 grid grid-cols-10 gap-2 z-50",
            children: emojis.map({
                "ChatPage[emojis.map()]": (emoji, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: {
                            "ChatPage[emojis.map() > <button>.onClick]": ()=>{
                                setMessage({
                                    "ChatPage[emojis.map() > <button>.onClick > setMessage()]": (prev_4)=>prev_4 + emoji
                                }["ChatPage[emojis.map() > <button>.onClick > setMessage()]"]);
                                setShowEmojiPicker(false);
                            }
                        }["ChatPage[emojis.map() > <button>.onClick]"],
                        className: "text-2xl hover:bg-purple-100 rounded-lg p-2 transition",
                        children: emoji
                    }, index, false, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 745,
                        columnNumber: 53
                    }, this)
            }["ChatPage[emojis.map()]"])
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 744,
            columnNumber: 30
        }, this);
        $[112] = showEmojiPicker;
        $[113] = t46;
    } else {
        t46 = $[113];
    }
    let t47;
    if ($[114] !== showEmojiPicker) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: {
                "ChatPage[<button>.onClick]": ()=>setShowEmojiPicker(!showEmojiPicker)
            }["ChatPage[<button>.onClick]"],
            className: "bg-white/10 text-white px-4 py-4 rounded-full hover:bg-white/20 transition",
            children: "😊"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 761,
            columnNumber: 11
        }, this);
        $[114] = showEmojiPicker;
        $[115] = t47;
    } else {
        t47 = $[115];
    }
    let t48;
    if ($[116] === Symbol.for("react.memo_cache_sentinel")) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: {
                "ChatPage[<button>.onClick]": ()=>fileInputRef.current?.click()
            }["ChatPage[<button>.onClick]"],
            className: "bg-white/10 text-white px-4 py-4 rounded-full hover:bg-white/20 transition",
            children: "📎"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 771,
            columnNumber: 11
        }, this);
        $[116] = t48;
    } else {
        t48 = $[116];
    }
    let t49;
    if ($[117] !== handleTyping) {
        t49 = ({
            "ChatPage[<input>.onChange]": (e_3)=>{
                setMessage(e_3.target.value);
                handleTyping();
            }
        })["ChatPage[<input>.onChange]"];
        $[117] = handleTyping;
        $[118] = t49;
    } else {
        t49 = $[118];
    }
    let t50;
    if ($[119] !== message || $[120] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            value: message,
            onChange: t49,
            placeholder: "Type a message...",
            className: "flex-1 px-6 py-4 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 793,
            columnNumber: 11
        }, this);
        $[119] = message;
        $[120] = t49;
        $[121] = t50;
    } else {
        t50 = $[121];
    }
    let t51;
    if ($[122] === Symbol.for("react.memo_cache_sentinel")) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            className: "bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:scale-105 transition",
            children: "Send →"
        }, void 0, false, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 802,
            columnNumber: 11
        }, this);
        $[122] = t51;
    } else {
        t51 = $[122];
    }
    let t52;
    if ($[123] !== handleSendMessage || $[124] !== t47 || $[125] !== t50) {
        t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSendMessage,
            className: "p-4 bg-black/20 border-t border-white/10 flex gap-3",
            children: [
                t47,
                t48,
                t50,
                t51
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 809,
            columnNumber: 11
        }, this);
        $[123] = handleSendMessage;
        $[124] = t47;
        $[125] = t50;
        $[126] = t52;
    } else {
        t52 = $[126];
    }
    let t53;
    if ($[127] !== t40 || $[128] !== t41 || $[129] !== t45 || $[130] !== t46 || $[131] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 flex flex-col",
            children: [
                t40,
                t41,
                t45,
                t46,
                t52
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 819,
            columnNumber: 11
        }, this);
        $[127] = t40;
        $[128] = t41;
        $[129] = t45;
        $[130] = t46;
        $[131] = t52;
        $[132] = t53;
    } else {
        t53 = $[132];
    }
    let t54;
    if ($[133] !== t39 || $[134] !== t53) {
        t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto flex-1 p-4 flex gap-4 max-w-7xl",
            children: [
                t39,
                t53
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 831,
            columnNumber: 11
        }, this);
        $[133] = t39;
        $[134] = t53;
        $[135] = t54;
    } else {
        t54 = $[135];
    }
    let t55;
    if ($[136] !== t20 || $[137] !== t37 || $[138] !== t38 || $[139] !== t54) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col",
            children: [
                t20,
                t37,
                t38,
                t54
            ]
        }, void 0, true, {
            fileName: "[project]/app/chat/page.tsx",
            lineNumber: 840,
            columnNumber: 11
        }, this);
        $[136] = t20;
        $[137] = t37;
        $[138] = t38;
        $[139] = t54;
        $[140] = t55;
    } else {
        t55 = $[140];
    }
    return t55;
}
_s(ChatPage, "yce6hGxTMxIKLg3RLxQDt0AvYiM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ChatPage;
function _ChatPageNotificationsMap(notif_0, idx) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-purple-50 p-3 rounded-lg mb-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "font-semibold text-sm text-gray-800",
                children: notif_0.sender
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 852,
                columnNumber: 70
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-gray-600",
                children: notif_0.message
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 852,
                columnNumber: 141
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-gray-400 mt-1",
                children: new Date(notif_0.timestamp).toLocaleTimeString()
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 852,
                columnNumber: 199
            }, this)
        ]
    }, idx, true, {
        fileName: "[project]/app/chat/page.tsx",
        lineNumber: 852,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "ChatPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_chat_page_tsx_9f2a1abf._.js.map
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/crypto-browser.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearSecretKey",
    ()=>clearSecretKey,
    "getSecretKey",
    ()=>getSecretKey,
    "hasSecretKey",
    ()=>hasSecretKey,
    "requestDecryption",
    ()=>requestDecryption,
    "storeSecretKey",
    ()=>storeSecretKey
]);
function storeSecretKey(username, secretKey) {
    try {
        const obfuscated = btoa(secretKey);
        localStorage.setItem(`${username}_secret_key`, obfuscated);
        console.log('🔐 Secret key stored securely');
    } catch (err) {
        console.error('Error storing secret key:', err);
    }
}
function getSecretKey(username) {
    try {
        const obfuscated = localStorage.getItem(`${username}_secret_key`);
        if (!obfuscated) return null;
        return atob(obfuscated);
    } catch (err) {
        console.error('Error retrieving secret key:', err);
        return null;
    }
}
function clearSecretKey(username) {
    localStorage.removeItem(`${username}_secret_key`);
    console.log('🗑️ Secret key cleared');
}
async function requestDecryption(kemCiphertext, secretKey) {
    const response = await fetch('/api/decrypt-kem', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            kemCiphertext,
            secretKey
        })
    });
    if (!response.ok) {
        throw new Error('Decryption request failed');
    }
    const data = await response.json();
    const sessionKeyBytes = Uint8Array.from(atob(data.sessionKey), (c)=>c.charCodeAt(0));
    return sessionKeyBytes.buffer;
}
function hasSecretKey(username) {
    return localStorage.getItem(`${username}_secret_key`) !== null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/chat/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/socket.io-client/build/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$crypto$2d$browser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/crypto-browser.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const emojis = [
    '😀',
    '😂',
    '😍',
    '🥰',
    '😎',
    '🤔',
    '😭',
    '😱',
    '🔥',
    '💯',
    '👍',
    '👎',
    '❤️',
    '💔',
    '🎉',
    '🎊',
    '✨',
    '⭐',
    '🌟',
    '💫'
];
function ChatPage() {
    _s();
    const [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [profilePicture, setProfilePicture] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [recipient, setRecipient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [allMessages, setAllMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); // Store ALL messages
    const [socket, setSocket] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isTyping, setIsTyping] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [userStatus, setUserStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [showEmojiPicker, setShowEmojiPicker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [typingUser, setTypingUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [chatMode, setChatMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('private');
    const [groups, setGroups] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedGroup, setSelectedGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [showNotifications, setShowNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newGroupName, setNewGroupName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showCreateGroup, setShowCreateGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [groupMembers, setGroupMembers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [secretKey, setSecretKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [hasKeyLoaded, setHasKeyLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const typingTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const scrollToBottom = ()=>messagesEndRef.current?.scrollIntoView({
            behavior: 'smooth'
        });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(scrollToBottom, [
        messages
    ]);
    // Load secret key on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatPage.useEffect": ()=>{
            const storedUsername = localStorage.getItem('username');
            if (storedUsername) {
                const key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$crypto$2d$browser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSecretKey"])(storedUsername);
                if (key) {
                    setSecretKey(key);
                    setHasKeyLoaded(true);
                    console.log('🔑 Secret key loaded for', storedUsername);
                } else {
                    console.warn('⚠️ No secret key found - messages cannot be decrypted');
                }
            }
        }
    }["ChatPage.useEffect"], []);
    // Filter messages when recipient or chat mode changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatPage.useEffect": ()=>{
            if (chatMode === 'private' && recipient) {
                // Show only messages between current user and selected recipient
                const filtered = allMessages.filter({
                    "ChatPage.useEffect.filtered": (msg)=>!msg.isGroup && (msg.sender === username && msg.receiver === recipient || msg.sender === recipient && msg.receiver === username)
                }["ChatPage.useEffect.filtered"]);
                setMessages(filtered);
                console.log(`📂 Filtered ${filtered.length} messages for chat with ${recipient}`);
            } else if (chatMode === 'group' && selectedGroup) {
                // Show only messages for selected group
                const filtered_0 = allMessages.filter({
                    "ChatPage.useEffect.filtered_0": (msg_0)=>msg_0.isGroup && msg_0.groupName === selectedGroup
                }["ChatPage.useEffect.filtered_0"]);
                setMessages(filtered_0);
            } else {
                setMessages([]);
            }
        }
    }["ChatPage.useEffect"], [
        recipient,
        selectedGroup,
        chatMode,
        allMessages,
        username
    ]);
    // Decrypt incoming message
    const decryptIncomingMessage = async (msg_1, userSecretKey)=>{
        try {
            if (!msg_1.encryptedMessage || !msg_1.kemCiphertext || !msg_1.iv || !msg_1.authTag) {
                console.error('Missing encryption data:', {
                    hasEncrypted: !!msg_1.encryptedMessage,
                    hasCiphertext: !!msg_1.kemCiphertext,
                    hasIv: !!msg_1.iv,
                    hasAuthTag: !!msg_1.authTag
                });
                throw new Error('Missing encryption data');
            }
            console.log('🔓 Starting decryption for message from', msg_1.sender);
            console.log('📊 Encryption data lengths:', {
                encrypted: msg_1.encryptedMessage?.length || 0,
                ciphertext: msg_1.kemCiphertext?.length || 0,
                iv: msg_1.iv?.length || 0,
                authTag: msg_1.authTag?.length || 0
            });
            // Debug: Show the actual base64 strings
            console.log('🔍 Base64 data samples:', {
                encryptedSample: msg_1.encryptedMessage?.substring(0, 20) + '...',
                ivSample: msg_1.iv?.substring(0, 20) + '...',
                authTagSample: msg_1.authTag?.substring(0, 20) + '...'
            });
            // Step 1: Get session key from server by decapsulating KEM
            const response = await fetch('/api/decrypt-kem', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    kemCiphertext: msg_1.kemCiphertext,
                    secretKey: userSecretKey
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                console.error('KEM decapsulation failed:', errorData);
                throw new Error('KEM decapsulation failed');
            }
            const data = await response.json();
            const sessionKeyBase64 = data.sessionKey;
            console.log('✅ Session key received from server');
            // Step 2: Prepare decryption with Web Crypto API
            const sessionKeyBytes = Uint8Array.from(atob(sessionKeyBase64), (c)=>c.charCodeAt(0));
            if (sessionKeyBytes.length !== 32) {
                console.error('Invalid session key length:', sessionKeyBytes.length);
                throw new Error('Invalid session key length');
            }
            const cryptoKey = await window.crypto.subtle.importKey('raw', sessionKeyBytes, {
                name: 'AES-GCM'
            }, false, [
                'decrypt'
            ]);
            // Step 3: Prepare encrypted data
            // IMPORTANT: The issue is here - we need to handle the format correctly
            const encryptedBytes = Uint8Array.from(atob(msg_1.encryptedMessage), (c_0)=>c_0.charCodeAt(0));
            const ivBytes = Uint8Array.from(atob(msg_1.iv), (c_1)=>c_1.charCodeAt(0));
            const authTagBytes = Uint8Array.from(atob(msg_1.authTag), (c_2)=>c_2.charCodeAt(0));
            console.log('🔧 Decryption components:', {
                encryptedLen: encryptedBytes.length,
                ivLen: ivBytes.length,
                authTagLen: authTagBytes.length,
                sessionKeyLen: sessionKeyBytes.length
            });
            // For Web Crypto API (browser), we need to append auth tag to ciphertext
            // This is different from Node.js where they're separate
            const ciphertextWithTag = new Uint8Array(encryptedBytes.length + authTagBytes.length);
            ciphertextWithTag.set(encryptedBytes, 0);
            ciphertextWithTag.set(authTagBytes, encryptedBytes.length);
            console.log('📦 Combined ciphertext+tag length:', ciphertextWithTag.length);
            // Step 4: Decrypt
            let decrypted;
            try {
                decrypted = await window.crypto.subtle.decrypt({
                    name: 'AES-GCM',
                    iv: ivBytes
                }, cryptoKey, ciphertextWithTag);
            } catch (decryptErr) {
                console.error('❌ AES-GCM decryption failed:', decryptErr);
                console.error('This usually means: wrong key, corrupted data, or tampered message');
                throw new Error('AES decryption failed - possible key mismatch');
            }
            const decoder = new TextDecoder();
            const decryptedText = decoder.decode(decrypted);
            console.log('✅ Decryption successful:', decryptedText.substring(0, 20) + '...');
            return decryptedText;
        } catch (err) {
            console.error('💥 Decryption error:', err);
            if (err instanceof Error) {
                return `[❌ Decryption Failed: ${err.message}]`;
            }
            return '[❌ Decryption Failed]';
        }
    };
    // SOCKET SETUP
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatPage.useEffect": ()=>{
            const storedUsername_0 = localStorage.getItem('username');
            const storedProfile = localStorage.getItem('profilePicture');
            if (!storedUsername_0) {
                router.push('/');
                return;
            }
            setUsername(storedUsername_0);
            if (storedProfile) setProfilePicture(storedProfile);
            const newSocket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])('http://localhost:3000', {
                transports: [
                    'websocket'
                ]
            });
            newSocket.on('connect', {
                "ChatPage.useEffect": ()=>{
                    console.log('🟢 Connected:', newSocket.id);
                    newSocket.emit('register_user', {
                        username: storedUsername_0,
                        profilePicture: storedProfile
                    });
                    newSocket.emit('get_all_statuses');
                }
            }["ChatPage.useEffect"]);
            newSocket.on('user_status', {
                "ChatPage.useEffect": (data_0)=>{
                    setUserStatus({
                        "ChatPage.useEffect": (prev)=>({
                                ...prev,
                                [data_0.username]: data_0.status
                            })
                    }["ChatPage.useEffect"]);
                }
            }["ChatPage.useEffect"]);
            newSocket.on('all_users_status', {
                "ChatPage.useEffect": (statuses)=>{
                    setUserStatus(statuses);
                }
            }["ChatPage.useEffect"]);
            // Handle encrypted private messages
            newSocket.on('receive_encrypted_message', {
                "ChatPage.useEffect": async (data_1)=>{
                    console.log('📨 Received encrypted message:', {
                        from: data_1.sender,
                        to: data_1.receiver,
                        currentUser: storedUsername_0
                    });
                    // Store ALL messages (don't filter here)
                    if (!data_1.isGroup) {
                        // Create unique ID for this message
                        const messageId = `${data_1.sender}-${data_1.receiver}-${Date.now()}`;
                        const encMsg = {
                            sender: data_1.sender,
                            receiver: data_1.receiver,
                            text: '🔒 [Encrypted - Decrypting...]',
                            timestamp: new Date(data_1.timestamp),
                            encryptedMessage: data_1.encryptedMessage,
                            kemCiphertext: data_1.kemCiphertext,
                            iv: data_1.iv,
                            authTag: data_1.authTag,
                            isDecrypted: false,
                            decrypting: true,
                            imageUrl: data_1.imageUrl
                        };
                        // Add to ALL messages storage
                        setAllMessages({
                            "ChatPage.useEffect": (prev_0)=>[
                                    ...prev_0,
                                    encMsg
                                ]
                        }["ChatPage.useEffect"]);
                        // Wait a bit to ensure state is updated and secret key is loaded
                        setTimeout({
                            "ChatPage.useEffect": async ()=>{
                                const userSecretKey_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$crypto$2d$browser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSecretKey"])(storedUsername_0);
                                console.log('🔍 Decryption check:', {
                                    currentUser: storedUsername_0,
                                    messageSender: data_1.sender,
                                    messageReceiver: data_1.receiver,
                                    hasSecretKey: !!userSecretKey_0,
                                    shouldDecrypt: data_1.receiver === storedUsername_0
                                });
                                if (!userSecretKey_0) {
                                    console.error('❌ No secret key found for', storedUsername_0);
                                    setAllMessages({
                                        "ChatPage.useEffect": (prev_1)=>prev_1.map({
                                                "ChatPage.useEffect": (msg_2)=>msg_2.timestamp.getTime() === encMsg.timestamp.getTime() && msg_2.sender === encMsg.sender && msg_2.receiver === encMsg.receiver ? {
                                                        ...msg_2,
                                                        text: '⚠️ [No Secret Key - Cannot Decrypt]',
                                                        decrypting: false
                                                    } : msg_2
                                            }["ChatPage.useEffect"])
                                    }["ChatPage.useEffect"]);
                                    return;
                                }
                                try {
                                    console.log('🔓 Starting decryption for message from', encMsg.sender);
                                    const decrypted_0 = await decryptIncomingMessage(encMsg, userSecretKey_0);
                                    // Update the message in allMessages
                                    setAllMessages({
                                        "ChatPage.useEffect": (prev_3)=>prev_3.map({
                                                "ChatPage.useEffect": (msg_4)=>msg_4.timestamp.getTime() === encMsg.timestamp.getTime() && msg_4.sender === encMsg.sender && msg_4.receiver === encMsg.receiver ? {
                                                        ...msg_4,
                                                        text: decrypted_0,
                                                        isDecrypted: true,
                                                        decrypting: false
                                                    } : msg_4
                                            }["ChatPage.useEffect"])
                                    }["ChatPage.useEffect"]);
                                    console.log('✅ Message decrypted:', decrypted_0.substring(0, 50));
                                } catch (err_0) {
                                    console.error('❌ Auto-decryption failed:', err_0);
                                    setAllMessages({
                                        "ChatPage.useEffect": (prev_2)=>prev_2.map({
                                                "ChatPage.useEffect": (msg_3)=>msg_3.timestamp.getTime() === encMsg.timestamp.getTime() && msg_3.sender === encMsg.sender && msg_3.receiver === encMsg.receiver ? {
                                                        ...msg_3,
                                                        text: err_0 instanceof Error ? `❌ [${err_0.message}]` : '❌ [Decryption Failed]',
                                                        decrypting: false
                                                    } : msg_3
                                            }["ChatPage.useEffect"])
                                    }["ChatPage.useEffect"]);
                                }
                            }
                        }["ChatPage.useEffect"], 100); // Small delay to ensure state updates
                        // Show notification if not in the current chat
                        const isCurrentChat = data_1.sender === recipient && data_1.receiver === storedUsername_0 || data_1.sender === storedUsername_0 && data_1.receiver === recipient;
                        if (!isCurrentChat && data_1.sender !== storedUsername_0) {
                            setNotifications({
                                "ChatPage.useEffect": (prev_4)=>[
                                        {
                                            sender: data_1.sender,
                                            message: 'New encrypted message',
                                            timestamp: new Date()
                                        },
                                        ...prev_4
                                    ]
                            }["ChatPage.useEffect"]);
                        }
                    }
                }
            }["ChatPage.useEffect"]);
            // Handle group messages
            newSocket.on('receive_group_message', {
                "ChatPage.useEffect": (data_2)=>{
                    if (data_2.isGroup) {
                        setAllMessages({
                            "ChatPage.useEffect": (prev_5)=>[
                                    ...prev_5,
                                    {
                                        ...data_2,
                                        isGroup: true
                                    }
                                ]
                        }["ChatPage.useEffect"]);
                    }
                }
            }["ChatPage.useEffect"]);
            newSocket.on('notification', {
                "ChatPage.useEffect": (data_3)=>{
                    const notif = {
                        sender: data_3.sender,
                        message: data_3.message,
                        timestamp: new Date()
                    };
                    setNotifications({
                        "ChatPage.useEffect": (prev_6)=>[
                                notif,
                                ...prev_6
                            ]
                    }["ChatPage.useEffect"]);
                }
            }["ChatPage.useEffect"]);
            newSocket.on('group_created', {
                "ChatPage.useEffect": (data_4)=>setGroups({
                        "ChatPage.useEffect": (prev_7)=>[
                                ...prev_7,
                                data_4.groupName
                            ]
                    }["ChatPage.useEffect"])
            }["ChatPage.useEffect"]);
            newSocket.on('all_groups', {
                "ChatPage.useEffect": (data_5)=>setGroups(data_5)
            }["ChatPage.useEffect"]);
            newSocket.on('group_members', {
                "ChatPage.useEffect": (data_6)=>{
                    if (selectedGroup === data_6.groupName) setGroupMembers(data_6.members);
                }
            }["ChatPage.useEffect"]);
            newSocket.on('user_typing', {
                "ChatPage.useEffect": (data_7)=>{
                    setTypingUser(data_7.sender);
                    setIsTyping(true);
                }
            }["ChatPage.useEffect"]);
            newSocket.on('user_stopped_typing', {
                "ChatPage.useEffect": ()=>{
                    setIsTyping(false);
                    setTypingUser('');
                }
            }["ChatPage.useEffect"]);
            setSocket(newSocket);
            return ({
                "ChatPage.useEffect": ()=>{
                    newSocket.close();
                }
            })["ChatPage.useEffect"];
        }
    }["ChatPage.useEffect"], [
        router
    ]);
    const handleCreateGroup = ()=>{
        if (!socket || !newGroupName.trim()) return;
        socket.emit('create_group', {
            groupName: newGroupName.trim(),
            creator: username
        });
        setSelectedGroup(newGroupName.trim());
        socket.emit('join_group', {
            groupName: newGroupName.trim(),
            username
        });
        setNewGroupName('');
        setShowCreateGroup(false);
        setChatMode('group');
    };
    const handleJoinGroup = (groupName)=>{
        if (!socket) return;
        setSelectedGroup(groupName);
        socket.emit('join_group', {
            groupName,
            username
        });
        setChatMode('group');
    };
    const handleFileUpload = async (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', 'message');
        try {
            const res = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            const data_8 = await res.json();
            if (data_8.url) sendMessageWithImage(data_8.url);
        } catch (err_1) {
            console.error('Upload failed:', err_1);
        }
    };
    const sendMessageWithImage = (imageUrl)=>{
        if (!socket) return;
        if (chatMode === 'private' && !recipient.trim()) {
            alert('Please enter a recipient username');
            return;
        }
        if (chatMode === 'group' && !selectedGroup) {
            alert('Please select a group first');
            return;
        }
        const msg_5 = {
            sender: username,
            receiver: chatMode === 'private' ? recipient : undefined,
            groupName: chatMode === 'group' ? selectedGroup : undefined,
            text: message.trim(),
            imageUrl,
            isGroup: chatMode === 'group',
            timestamp: new Date()
        };
        socket.emit(chatMode === 'private' ? 'send_message' : 'send_group_message', msg_5);
        setMessage('');
    };
    const handleSendMessage = (e_0)=>{
        e_0.preventDefault();
        if (!socket || !message.trim()) return;
        if (chatMode === 'private' && !recipient.trim()) {
            alert('Please enter a recipient username');
            return;
        }
        if (chatMode === 'group' && !selectedGroup) {
            alert('Please select a group first');
            return;
        }
        const msg_6 = {
            sender: username,
            receiver: chatMode === 'private' ? recipient : undefined,
            groupName: chatMode === 'group' ? selectedGroup : undefined,
            text: message.trim(),
            isGroup: chatMode === 'group',
            timestamp: new Date()
        };
        console.log('📤 Sending message:', msg_6);
        socket.emit(chatMode === 'private' ? 'send_message' : 'send_group_message', msg_6);
        setMessage('');
    };
    const handleTyping = ()=>{
        if (!socket) return;
        if (chatMode === 'private' && recipient) socket.emit('typing', {
            sender: username,
            receiver: recipient
        });
        else if (chatMode === 'group' && selectedGroup) socket.emit('typing_group', {
            groupName: selectedGroup,
            sender: username
        });
        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(()=>{
            if (chatMode === 'private' && recipient) socket.emit('stop_typing', {
                sender: username,
                receiver: recipient
            });
            else if (chatMode === 'group' && selectedGroup) socket.emit('stop_typing_group', {
                groupName: selectedGroup,
                sender: username
            });
        }, 1000);
    };
    const handleLogout = ()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$crypto$2d$browser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSecretKey"])(username);
        localStorage.removeItem('username');
        localStorage.removeItem('profilePicture');
        socket?.close();
        router.push('/');
    };
    const getRecipientStatus = ()=>{
        if (!recipient || !userStatus) return false;
        return userStatus[recipient]?.toLowerCase() === 'online';
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "file",
                ref: fileInputRef,
                onChange: handleFileUpload,
                accept: "image/*",
                className: "hidden"
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 475,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-black/40 backdrop-blur-xl border-b border-white/10 shadow-2xl",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 py-4 flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full overflow-hidden flex items-center justify-center",
                                    children: profilePicture ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: profilePicture,
                                        alt: "Profile",
                                        className: "w-full h-full object-cover"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 482,
                                        columnNumber: 33
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-2xl",
                                        children: "👤"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 482,
                                        columnNumber: 117
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 481,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: "text-2xl font-bold text-white",
                                            children: "ChatVerse 🔐"
                                        }, void 0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 485,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-purple-300",
                                            children: [
                                                username,
                                                " ",
                                                hasKeyLoaded ? '• 🔑 Key Loaded' : '• ⚠️ No Key'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 486,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 484,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 480,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShowNotifications(!showNotifications),
                                    className: "relative bg-white/10 border border-white/20 text-white px-4 py-2 rounded-full hover:bg-white/20 transition",
                                    children: [
                                        "🔔",
                                        notifications.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center",
                                            children: notifications.length
                                        }, void 0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 495,
                                            columnNumber: 44
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 493,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex bg-white/10 rounded-full p-1 border border-white/20",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setChatMode('private'),
                                            className: `px-4 py-2 rounded-full transition ${chatMode === 'private' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-white/60 hover:text-white'}`,
                                            children: "👤 Private"
                                        }, void 0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 501,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setChatMode('group'),
                                            className: `px-4 py-2 rounded-full transition ${chatMode === 'group' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-white/60 hover:text-white'}`,
                                            children: "👥 Group"
                                        }, void 0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 502,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 500,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleLogout,
                                    className: "bg-red-500/20 border border-red-500/50 text-red-300 px-6 py-2 rounded-full hover:bg-red-500/30 transition font-semibold",
                                    children: "Logout"
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 505,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 492,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/chat/page.tsx",
                    lineNumber: 479,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 478,
                columnNumber: 7
            }, this),
            showNotifications && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-20 right-4 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/20 w-80 max-h-96 overflow-y-auto z-50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "font-bold text-lg mb-3 text-gray-800",
                        children: "Notifications"
                    }, void 0, false, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 512,
                        columnNumber: 11
                    }, this),
                    notifications.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-500 text-sm",
                        children: "No notifications"
                    }, void 0, false, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 513,
                        columnNumber: 41
                    }, this) : notifications.map((notif_0, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-purple-50 p-3 rounded-lg mb-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-semibold text-sm text-gray-800",
                                    children: notif_0.sender
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 514,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-600",
                                    children: notif_0.message
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 515,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-400 mt-1",
                                    children: new Date(notif_0.timestamp).toLocaleTimeString()
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 516,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, idx, true, {
                            fileName: "[project]/app/chat/page.tsx",
                            lineNumber: 513,
                            columnNumber: 137
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 511,
                columnNumber: 29
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto flex-1 p-4 flex gap-4 max-w-7xl",
                children: [
                    chatMode === 'group' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-80 bg-white/10 rounded-3xl p-6 border border-white/20 flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-bold text-white",
                                        children: "Groups"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 524,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setShowCreateGroup(!showCreateGroup),
                                        className: "bg-gradient-to-r from-indigo-600 to-purple-600 text-white w-10 h-10 rounded-full font-bold text-xl hover:scale-110 transition",
                                        children: "+"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 525,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 523,
                                columnNumber: 13
                            }, this),
                            showCreateGroup && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: newGroupName,
                                        onChange: (e_1)=>setNewGroupName(e_1.target.value),
                                        placeholder: "Group name",
                                        className: "w-full px-4 py-2 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 529,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleCreateGroup,
                                        className: "w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-full font-semibold hover:scale-105 transition",
                                        children: "Create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 530,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 528,
                                columnNumber: 33
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 overflow-y-auto space-y-2",
                                children: groups.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-white/50 text-sm text-center mt-4",
                                    children: "No groups yet"
                                }, void 0, false, {
                                    fileName: "[project]/app/chat/page.tsx",
                                    lineNumber: 534,
                                    columnNumber: 38
                                }, this) : groups.map((group, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleJoinGroup(group),
                                        className: `w-full p-4 rounded-2xl transition ${selectedGroup === group ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'bg-white/5 text-white hover:bg-white/10'}`,
                                        children: [
                                            "👥 ",
                                            group
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 534,
                                        columnNumber: 137
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 533,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 522,
                        columnNumber: 34
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 flex flex-col",
                        children: [
                            chatMode === 'private' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/10 p-6 rounded-3xl mb-4 border border-white/20",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-lg font-semibold text-white mb-3",
                                        children: "🎯 Chat with"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 543,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-3 items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                value: recipient,
                                                onChange: (e_2)=>setRecipient(e_2.target.value),
                                                placeholder: "Enter recipient's username",
                                                className: "flex-1 px-6 py-3 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
                                            }, void 0, false, {
                                                fileName: "[project]/app/chat/page.tsx",
                                                lineNumber: 545,
                                                columnNumber: 17
                                            }, this),
                                            recipient && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 bg-white/10 px-4 py-3 rounded-full border border-white/20",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `w-3 h-3 rounded-full ${getRecipientStatus() ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/chat/page.tsx",
                                                        lineNumber: 547,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `text-sm font-semibold ${getRecipientStatus() ? 'text-green-300' : 'text-gray-400'}`,
                                                        children: getRecipientStatus() ? 'Online' : 'Offline'
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/chat/page.tsx",
                                                        lineNumber: 548,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/chat/page.tsx",
                                                lineNumber: 546,
                                                columnNumber: 31
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 544,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 542,
                                columnNumber: 38
                            }, this),
                            chatMode === 'group' && selectedGroup && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/10 p-4 rounded-3xl mb-4 border border-white/20",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold text-white",
                                        children: [
                                            "👥 ",
                                            selectedGroup
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 556,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-white/60",
                                        children: "Group Chat"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 557,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 555,
                                columnNumber: 53
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 bg-white/5 rounded-3xl overflow-y-auto p-6 space-y-4 relative",
                                children: [
                                    messages.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-center h-full",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-white/40 text-lg",
                                            children: chatMode === 'private' ? recipient ? '🔐 Start secure chatting!' : '🔐 Enter a recipient username to start chatting' : 'Select a group to start chatting'
                                        }, void 0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 563,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 562,
                                        columnNumber: 38
                                    }, this) : messages.map((msg_7, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `flex ${msg_7.sender === username ? 'justify-end' : 'justify-start'}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `max-w-md px-6 py-3 rounded-3xl shadow-lg ${msg_7.sender === username ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'bg-white/10 text-white'} border border-white/20`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2 mb-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs font-semibold opacity-80",
                                                                children: msg_7.sender
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/chat/page.tsx",
                                                                lineNumber: 569,
                                                                columnNumber: 23
                                                            }, this),
                                                            msg_7.decrypting && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs bg-yellow-500/30 px-2 py-1 rounded-full animate-pulse",
                                                                children: "🔄 Decrypting..."
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/chat/page.tsx",
                                                                lineNumber: 570,
                                                                columnNumber: 44
                                                            }, this),
                                                            msg_7.isDecrypted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs bg-green-500/30 px-2 py-1 rounded-full",
                                                                children: "✅ Decrypted"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/chat/page.tsx",
                                                                lineNumber: 571,
                                                                columnNumber: 45
                                                            }, this),
                                                            !msg_7.isDecrypted && msg_7.encryptedMessage && !msg_7.decrypting && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs bg-red-500/30 px-2 py-1 rounded-full",
                                                                children: "🔒 Encrypted"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/chat/page.tsx",
                                                                lineNumber: 572,
                                                                columnNumber: 93
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/chat/page.tsx",
                                                        lineNumber: 568,
                                                        columnNumber: 21
                                                    }, this),
                                                    msg_7.imageUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: msg_7.imageUrl,
                                                        alt: "img",
                                                        className: "rounded-lg mb-2 max-w-xs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/chat/page.tsx",
                                                        lineNumber: 574,
                                                        columnNumber: 40
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "break-words",
                                                        children: msg_7.text
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/chat/page.tsx",
                                                        lineNumber: 575,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs mt-2 opacity-60",
                                                        children: new Date(msg_7.timestamp).toLocaleTimeString()
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/chat/page.tsx",
                                                        lineNumber: 576,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/chat/page.tsx",
                                                lineNumber: 567,
                                                columnNumber: 19
                                            }, this)
                                        }, i_0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 566,
                                            columnNumber: 53
                                        }, this)),
                                    isTyping && typingUser && typingUser === recipient && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-start",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white/10 px-4 py-2 rounded-full",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-white/70",
                                                children: [
                                                    typingUser,
                                                    " is typing..."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/chat/page.tsx",
                                                lineNumber: 581,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/chat/page.tsx",
                                            lineNumber: 580,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 579,
                                        columnNumber: 68
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        ref: messagesEndRef
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 584,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 561,
                                columnNumber: 11
                            }, this),
                            showEmojiPicker && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute bottom-24 left-6 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/20 grid grid-cols-10 gap-2 z-50",
                                children: emojis.map((emoji, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>{
                                            setMessage((prev_8)=>prev_8 + emoji);
                                            setShowEmojiPicker(false);
                                        },
                                        className: "text-2xl hover:bg-purple-100 rounded-lg p-2 transition",
                                        children: emoji
                                    }, index, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 589,
                                        columnNumber: 45
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 588,
                                columnNumber: 31
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                onSubmit: handleSendMessage,
                                className: "p-4 bg-black/20 border-t border-white/10 flex gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setShowEmojiPicker(!showEmojiPicker),
                                        className: "bg-white/10 text-white px-4 py-4 rounded-full hover:bg-white/20 transition",
                                        children: "😊"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 599,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>fileInputRef.current?.click(),
                                        className: "bg-white/10 text-white px-4 py-4 rounded-full hover:bg-white/20 transition",
                                        children: "📎"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 600,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: message,
                                        onChange: (e_3)=>{
                                            setMessage(e_3.target.value);
                                            handleTyping();
                                        },
                                        placeholder: "Type a message...",
                                        className: "flex-1 px-6 py-4 bg-white/10 border border-white/20 rounded-full text-white placeholder-white/50"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 601,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        className: "bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:scale-105 transition",
                                        children: "Send →"
                                    }, void 0, false, {
                                        fileName: "[project]/app/chat/page.tsx",
                                        lineNumber: 605,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/chat/page.tsx",
                                lineNumber: 598,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/chat/page.tsx",
                        lineNumber: 541,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/chat/page.tsx",
                lineNumber: 521,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/chat/page.tsx",
        lineNumber: 474,
        columnNumber: 10
    }, this);
}
_s(ChatPage, "0wgBfmE9jXxLYGtYBQP3kJgwTk0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ChatPage;
var _c;
__turbopack_context__.k.register(_c, "ChatPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_f8ca13a6._.js.map
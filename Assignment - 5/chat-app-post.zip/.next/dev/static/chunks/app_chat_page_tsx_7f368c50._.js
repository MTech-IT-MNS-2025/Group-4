(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_69e5a515._.js",
  "static/chunks/app_f8ca13a6._.js"
],
    source: "dynamic"
});

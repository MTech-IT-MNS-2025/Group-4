#include <napi.h>
#include <oqs/oqs.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <cstring>

// Generate KEM keypair
Napi::Object GenerateKEMKeypair(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    const char* kem_name = "Kyber768";
    OQS_KEM *kem = OQS_KEM_new(kem_name);
    
    if (kem == nullptr) {
        Napi::Error::New(env, "Failed to initialize KEM").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    uint8_t *public_key = (uint8_t *)malloc(kem->length_public_key);
    uint8_t *secret_key = (uint8_t *)malloc(kem->length_secret_key);
    
    OQS_STATUS rc = OQS_KEM_keypair(kem, public_key, secret_key);
    
    Napi::Object result = Napi::Object::New(env);
    
    if (rc == OQS_SUCCESS) {
        Napi::Buffer<uint8_t> pubKeyBuffer = Napi::Buffer<uint8_t>::Copy(env, public_key, kem->length_public_key);
        Napi::Buffer<uint8_t> secKeyBuffer = Napi::Buffer<uint8_t>::Copy(env, secret_key, kem->length_secret_key);
        
        result.Set("publicKey", pubKeyBuffer);
        result.Set("secretKey", secKeyBuffer);
        result.Set("algorithm", kem_name);
    } else {
        Napi::Error::New(env, "Keypair generation failed").ThrowAsJavaScriptException();
    }
    
    // Securely wipe memory
    OPENSSL_cleanse(public_key, kem->length_public_key);
    OPENSSL_cleanse(secret_key, kem->length_secret_key);
    free(public_key);
    free(secret_key);
    OQS_KEM_free(kem);
    
    return result;
}

// KEM Encapsulate
Napi::Object KEM_Encapsulate(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    
    if (info.Length() < 1 || !info[0].IsBuffer()) {
        Napi::TypeError::New(env, "Expected public key buffer").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    Napi::Buffer<uint8_t> pubKeyBuffer = info[0].As<Napi::Buffer<uint8_t>>();
    uint8_t* public_key = pubKeyBuffer.Data();
    
    const char* kem_name = "Kyber768";
    OQS_KEM *kem = OQS_KEM_new(kem_name);
    
    if (kem == nullptr) {
        Napi::Error::New(env, "Failed to initialize KEM").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    uint8_t *ciphertext = (uint8_t *)malloc(kem->length_ciphertext);
    uint8_t *shared_secret = (uint8_t *)malloc(kem->length_shared_secret);
    
    OQS_STATUS rc = OQS_KEM_encaps(kem, ciphertext, shared_secret, public_key);
    
    Napi::Object result = Napi::Object::New(env);
    
    if (rc == OQS_SUCCESS) {
        Napi::Buffer<uint8_t> ctBuffer = Napi::Buffer<uint8_t>::Copy(env, ciphertext, kem->length_ciphertext);
        Napi::Buffer<uint8_t> ssBuffer = Napi::Buffer<uint8_t>::Copy(env, shared_secret, kem->length_shared_secret);
        
        result.Set("ciphertext", ctBuffer);
        result.Set("sharedSecret", ssBuffer);
    } else {
        Napi::Error::New(env, "Encapsulation failed").ThrowAsJavaScriptException();
    }
    
    // Securely wipe memory
    OPENSSL_cleanse(ciphertext, kem->length_ciphertext);
    OPENSSL_cleanse(shared_secret, kem->length_shared_secret);
    free(ciphertext);
    free(shared_secret);
    OQS_KEM_free(kem);
    
    return result;
}

// KEM Decapsulate
Napi::Buffer<uint8_t> KEM_Decapsulate(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    
    if (info.Length() < 2 || !info[0].IsBuffer() || !info[1].IsBuffer()) {
        Napi::TypeError::New(env, "Expected ciphertext and secret key buffers").ThrowAsJavaScriptException();
        return Napi::Buffer<uint8_t>::New(env, 0);
    }
    
    Napi::Buffer<uint8_t> ctBuffer = info[0].As<Napi::Buffer<uint8_t>>();
    Napi::Buffer<uint8_t> secKeyBuffer = info[1].As<Napi::Buffer<uint8_t>>();
    
    uint8_t* ciphertext = ctBuffer.Data();
    uint8_t* secret_key = secKeyBuffer.Data();
    
    const char* kem_name = "Kyber768";
    OQS_KEM *kem = OQS_KEM_new(kem_name);
    
    if (kem == nullptr) {
        Napi::Error::New(env, "Failed to initialize KEM").ThrowAsJavaScriptException();
        return Napi::Buffer<uint8_t>::New(env, 0);
    }
    
    uint8_t *shared_secret = (uint8_t *)malloc(kem->length_shared_secret);
    
    OQS_STATUS rc = OQS_KEM_decaps(kem, shared_secret, ciphertext, secret_key);
    
    Napi::Buffer<uint8_t> result = Napi::Buffer<uint8_t>::New(env, 0);
    
    if (rc == OQS_SUCCESS) {
        result = Napi::Buffer<uint8_t>::Copy(env, shared_secret, kem->length_shared_secret);
    } else {
        Napi::Error::New(env, "Decapsulation failed").ThrowAsJavaScriptException();
    }
    
    // Securely wipe memory
    OPENSSL_cleanse(shared_secret, kem->length_shared_secret);
    free(shared_secret);
    OQS_KEM_free(kem);
    
    return result;
}

// NEW: AES-256-GCM Encryption (OpenSSL)
Napi::Object AES_Encrypt(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    
    if (info.Length() < 2 || !info[0].IsString() || !info[1].IsBuffer()) {
        Napi::TypeError::New(env, "Expected plaintext (string) and key (buffer)").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    std::string plaintext = info[0].As<Napi::String>().Utf8Value();
    Napi::Buffer<uint8_t> keyBuffer = info[1].As<Napi::Buffer<uint8_t>>();
    uint8_t* key = keyBuffer.Data();
    size_t key_len = keyBuffer.Length();
    
    if (key_len != 32) {
        Napi::Error::New(env, "Key must be 32 bytes for AES-256").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    // Generate random IV (12 bytes for GCM)
    uint8_t iv[12];
    if (RAND_bytes(iv, 12) != 1) {
        Napi::Error::New(env, "Failed to generate IV").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        Napi::Error::New(env, "Failed to create cipher context").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    // Initialize encryption
    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Failed to initialize encryption").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    // Allocate ciphertext buffer
    int ciphertext_len = plaintext.length() + EVP_CIPHER_block_size(EVP_aes_256_gcm());
    uint8_t *ciphertext = (uint8_t *)malloc(ciphertext_len);
    
    int len;
    // Encrypt
    if (EVP_EncryptUpdate(ctx, ciphertext, &len, (uint8_t*)plaintext.c_str(), plaintext.length()) != 1) {
        free(ciphertext);
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Encryption failed").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    ciphertext_len = len;
    
    // Finalize
    if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
        free(ciphertext);
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Encryption finalization failed").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    ciphertext_len += len;
    
    // Get authentication tag
    uint8_t tag[16];
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag) != 1) {
        free(ciphertext);
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Failed to get auth tag").ThrowAsJavaScriptException();
        return Napi::Object::New(env);
    }
    
    // Create result object
    Napi::Object result = Napi::Object::New(env);
    result.Set("ciphertext", Napi::Buffer<uint8_t>::Copy(env, ciphertext, ciphertext_len));
    result.Set("iv", Napi::Buffer<uint8_t>::Copy(env, iv, 12));
    result.Set("authTag", Napi::Buffer<uint8_t>::Copy(env, tag, 16));
    
    // Cleanup - securely wipe sensitive data
    OPENSSL_cleanse(ciphertext, ciphertext_len);
    free(ciphertext);
    EVP_CIPHER_CTX_free(ctx);
    
    return result;
}

// NEW: AES-256-GCM Decryption (OpenSSL)
Napi::String AES_Decrypt(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    
    if (info.Length() < 4 || !info[0].IsBuffer() || !info[1].IsBuffer() || 
        !info[2].IsBuffer() || !info[3].IsBuffer()) {
        Napi::TypeError::New(env, "Expected ciphertext, key, iv, authTag (all buffers)").ThrowAsJavaScriptException();
        return Napi::String::New(env, "");
    }
    
    Napi::Buffer<uint8_t> ctBuffer = info[0].As<Napi::Buffer<uint8_t>>();
    Napi::Buffer<uint8_t> keyBuffer = info[1].As<Napi::Buffer<uint8_t>>();
    Napi::Buffer<uint8_t> ivBuffer = info[2].As<Napi::Buffer<uint8_t>>();
    Napi::Buffer<uint8_t> tagBuffer = info[3].As<Napi::Buffer<uint8_t>>();
    
    uint8_t* ciphertext = ctBuffer.Data();
    size_t ct_len = ctBuffer.Length();
    uint8_t* key = keyBuffer.Data();
    uint8_t* iv = ivBuffer.Data();
    uint8_t* tag = tagBuffer.Data();
    
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        Napi::Error::New(env, "Failed to create cipher context").ThrowAsJavaScriptException();
        return Napi::String::New(env, "");
    }
    
    // Initialize decryption
    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Failed to initialize decryption").ThrowAsJavaScriptException();
        return Napi::String::New(env, "");
    }
    
    // Allocate plaintext buffer
    uint8_t *plaintext = (uint8_t *)malloc(ct_len);
    int len;
    int plaintext_len;
    
    // Decrypt
    if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ct_len) != 1) {
        free(plaintext);
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Decryption failed").ThrowAsJavaScriptException();
        return Napi::String::New(env, "");
    }
    plaintext_len = len;
    
    // Set authentication tag
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, tag) != 1) {
        free(plaintext);
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Failed to set auth tag").ThrowAsJavaScriptException();
        return Napi::String::New(env, "");
    }
    
    // Finalize - this verifies the auth tag
    int ret = EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    
    if (ret <= 0) {
        // Authentication failed or decryption error
        OPENSSL_cleanse(plaintext, plaintext_len);
        free(plaintext);
        EVP_CIPHER_CTX_free(ctx);
        Napi::Error::New(env, "Decryption failed - authentication tag mismatch").ThrowAsJavaScriptException();
        return Napi::String::New(env, "");
    }
    plaintext_len += len;
    
    // Convert to string
    std::string result_str((char*)plaintext, plaintext_len);
    Napi::String result = Napi::String::New(env, result_str);
    
    // Cleanup - securely wipe
    OPENSSL_cleanse(plaintext, plaintext_len);
    free(plaintext);
    EVP_CIPHER_CTX_free(ctx);
    
    return result;
}

// Initialize module
Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports.Set("generateKEMKeypair", Napi::Function::New(env, GenerateKEMKeypair));
    exports.Set("kemEncapsulate", Napi::Function::New(env, KEM_Encapsulate));
    exports.Set("kemDecapsulate", Napi::Function::New(env, KEM_Decapsulate));
    exports.Set("aesEncrypt", Napi::Function::New(env, AES_Encrypt));
    exports.Set("aesDecrypt", Napi::Function::New(env, AES_Decrypt));
    return exports;
}

NODE_API_MODULE(pqcrypto, Init)

{
  "targets": [
    {
      "target_name": "pqcrypto",
      "sources": ["pqcrypto.cc"],
      "include_dirs": [
        "<!@(node -p \"require('node-addon-api').include\")",
        "/usr/local/include"
      ],
      "libraries": [
        "-L/usr/local/lib",
        "-loqs",
        "-lssl",
        "-lcrypto"
      ],
      "cflags!": ["-fno-exceptions"],
      "cflags_cc!": ["-fno-exceptions"],
      "defines": ["NAPI_DISABLE_CPP_EXCEPTIONS"],
      "cflags_cc": ["-std=c++11"]
    }
  ]
}
